/* ahitest: plays a 440 Hz tone for 3 seconds through ahi.device (unit 0) with the classic
   double-buffered, linked CMD_WRITE scheme and logs every request completion to DIZ:ahitest.txt */
#include <stdio.h>
#include <string.h>
#include <exec/exec.h>
#include <devices/ahi.h>
#include <proto/exec.h>
#include <proto/dos.h>

#define FRAMES 1024
#define FREQ   22050

int main( void )
{
	FILE* log = fopen("DIZ:ahitest.txt","w");
	struct MsgPort* port = CreateMsgPort();
	struct AHIRequest* req[2] = { NULL, NULL };
	short* buf[2];
	int i, n, err, phase = 0;
	ULONG t;
	if(!log) return 20;
	req[0] = (struct AHIRequest*)CreateIORequest(port,sizeof(struct AHIRequest));
	req[0]->ahir_Version = 4;
	err = OpenDevice((CONST_STRPTR)AHINAME,AHI_DEFAULT_UNIT,(struct IORequest*)req[0],0);
	fprintf(log,"OpenDevice unit 0: %d\n",err);
	if(err) { fclose(log); return 20; }
	req[1] = (struct AHIRequest*)AllocVec(sizeof(struct AHIRequest),MEMF_PUBLIC);
	CopyMem(req[0],req[1],sizeof(struct AHIRequest));
	buf[0] = (short*)AllocVec(FRAMES*4,MEMF_PUBLIC);
	buf[1] = (short*)AllocVec(FRAMES*4,MEMF_PUBLIC);

	/* 3 seconds of 1024 frame blocks, alternating the two requests, each linked to the other */
	n = (3*FREQ)/FRAMES;
	for(i=0;i<n;i++)
	{
		struct AHIRequest* r = req[i&1];
		struct AHIRequest* other = req[(i+1)&1];
		short* b = buf[i&1];
		int k;
		if(i>=2)
		{
			t = 0;
			while(!CheckIO((struct IORequest*)r)) { Delay(1); if(++t>150) { fprintf(log,"block %d: request never returned (3 s)\n",i); goto done; } }
			WaitIO((struct IORequest*)r);
			fprintf(log,"block %d: previous returned, io_Error %d, waited %lu ticks\n",i,(int)r->ahir_Std.io_Error,t);
		}
		for(k=0;k<FRAMES;k++) { short v = (short)(((phase++ % 50) < 25) ? 6000 : -6000); b[k*2]=v; b[k*2+1]=v; }
		r->ahir_Std.io_Message.mn_Node.ln_Pri = 0;
		r->ahir_Std.io_Command	= CMD_WRITE;
		r->ahir_Std.io_Data		= b;
		r->ahir_Std.io_Length	= FRAMES*4;
		r->ahir_Std.io_Offset	= 0;
		r->ahir_Frequency		= FREQ;
		r->ahir_Type			= AHIST_S16S;
		r->ahir_Volume			= 0x10000;
		r->ahir_Position		= 0x8000;
		r->ahir_Link			= (i>0) ? other : NULL;
		SendIO((struct IORequest*)r);
	}
	fprintf(log,"all %d blocks played\n",n);
done:
	for(i=0;i<2;i++) if(!CheckIO((struct IORequest*)req[i])) { AbortIO((struct IORequest*)req[i]); }
	for(i=0;i<2;i++) WaitIO((struct IORequest*)req[i]);
	CloseDevice((struct IORequest*)req[0]);
	fclose(log);
	return 0;
}
