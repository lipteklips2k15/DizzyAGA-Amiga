# DizzyAGE 2.4 for AmigaOS 3.x

This is a port of the DizzyAGE 2.4 engine (Alexandru and Cristina Simion) to AmigaOS 3.x, on an RTG
graphics card or the AGA chipset. It plays the existing Windows DizzyAGE games from their unchanged
`.pak` or `Data` folder.

## Status

Built with amiga-gcc and tested in WinUAE (AmigaOS 3.2, 68040) with *Dizzy 3.5*: title screens, menus
and gameplay with sound, on an RTG screen and on an AGA screen. Not yet tested on real hardware.

Speed on an emulated machine as fast as a real 25 MHz 68040 (`winuae-test/dizzy-bench.uae`), in
gameplay: about 7 frames drawn per second, with the game itself at full speed (see `frameskip`).
A PiStorm with Emu68 or a fast 68060 is far faster than that.

## Requirements (target machine)

- AmigaOS 3.x with a 68020+ CPU and FPU. A PiStorm with Emu68 is the intended target; a stock A1200 is far too slow.
- An RTG card driven by Picasso96 (or CyberGraphX), or the AGA chipset.
  - RTG: the engine uses the cybergraphics API, which P96 provides; the PiStorm RTG is fine. It looks for a
    320x240 16-bit mode, then falls back to 640x480 pixel-doubled, then 32-bit.
  - AGA (OS 3.1 or later): a 320x256 PAL (or 320x240 NTSC) 256 color screen. Colors get their own pens
    while there are free ones (exact for games with up to 256 colors, like Dizzy 3.5); on busier screens
    the palette is rebuilt from the most frequent colors. Used automatically when there is no RTG mode,
    or always with `aga=1`. With an Akiko chip (CD32, some accelerators) its hardware chunky to planar
    converter is used; otherwise graphics.library's WriteChunkyPixels.
- Sound through ahi.device, or directly through Paula (audio.device, 8 bit, two channels) with `paula=1`
  or when AHI can't be opened. Without either the game runs silent. If the sound device stops returning
  buffers for 2 seconds, the game logs a warning and continues silently instead of freezing.
  The amount of sound queued adapts: it starts at 120 ms, grows when the sound runs dry (a slow machine)
  and shrinks again to 100 ms when it doesn't, so sound effects lag as little as the machine allows.
- lowlevel.library for joystick / CD32 pad (optional).

## Building (MSYS2 + bebbo amiga-gcc)

    make -f Makefile.amiga -j4          # produces ./dizzy
    make -f Makefile.amiga strip        # optional: dizzy.stripped

Useful variables:

- `CPU="-mcpu=68020 -mtune=68040 -m68881"` tunes for Emu68 / 040. The default is
  `-mcpu=68020 -mtune=68020-60 -m68881`. Keep `-mcpu=68020 -m68881` in any variant: only that
  spelling makes gcc link libnix's hard-float 68020 libraries. `-m68020-60`, `-m68040` or
  `-mhard-float` silently link the 68000 soft-float libm instead, and the game crashes with
  Guru 80000004 on its first `floor()` call.
- `PREFIX=...` sets a different toolchain prefix.

You can also build the headless PC test build with a native gcc (`make -f Makefile.host`). Run it inside
a game folder as `dizzy-host 900 100 "300:28:down,305:28:up"`. It writes `frameNNNNN.ppm` screenshots
and `out.wav`.

## Installing a game

1. Copy the game folder (`dizzy.pak` and/or `Data/`, plus `dizzy.ini`) to the Amiga.
2. Put the `dizzy` executable next to it. **The executable name must match the .pak/.ini name**
   (`dizzy` -> `dizzy.pak`, `dizzy.ini`, `dizzy.log`), just like `dizzy.exe` on Windows.
3. Run it from the Shell (log messages appear there) or give it a Tool icon. The stack is set internally
   to 200 KB.

## Controls

The keys are the game's own (from `dizzy.ini`, stored as PC scancodes, mapped from Amiga raw keys):
cursor keys or Z/X move, Space jumps, Return is action, Esc/Q opens the menu.

| Key | Function |
|---|---|
| F9 | Mute |
| F11 (or HELP) | FPS display |
| Right-Amiga | Screenshot (`shotNNN.tga`) |
| F1 | Game info |
| Ctrl-C (in the Shell) | Quit |

Joystick in port 2 (lowlevel port 1): the fire / red button is ACTION, blue is JUMP, green is MENU.
With a one-button stick, UP also jumps in most Dizzy games. To make fire jump instead, set
`joystick_b0=1` and `joystick_b1=0` in the ini.

## Amiga options (`[AMIGA]` section in the game's ini, all optional)

    [AMIGA]
    width=320        ; back buffer size (320x240 is the native DizzyAGE screen)
    height=240
    scale=1          ; game pixel scale inside the back buffer
    depth=16         ; screen depth to ask for (15/16/24/32)
    double=0         ; 1 = open a 640x480 screen and pixel-double
    modeid=0x...     ; force a specific screen mode id
    vsync=0          ; 1 = WaitTOF before each blit
    audiofreq=22050  ; mixing rate (with Paula, the nearest its period allows: 22030 Hz on PAL)
    paula=0          ; 1 = sound through Paula (audio.device) instead of AHI
    joyport=1        ; lowlevel.library port
    aga=-1           ; 1 = 256 color AGA screen, 0 = RTG only, -1 = RTG if possible, else AGA
    akiko=1          ; on AGA, use the Akiko chip's chunky to planar converter if it's there
    directpresent=1  ; 1 = convert frames straight into the screen bitmap, 0 = WritePixelArray
    profile=0        ; 1 = log a frame time breakdown to dizzy.log every 5 seconds
    frameskip=4      ; when drawing can't keep up, run up to this many extra game frames per
                     ; drawn frame so the game keeps its speed (0 = slow down instead)

`[ADVANCED] cool=1` (the default in DizzyAGE inis) caps redraws at about 60 fps. The game logic always
runs at its own rate. Set `log=1` in `[ADVANCED]` to write `dizzy.log`, which is the first thing to
look at if something goes wrong.

## What was changed (search the source for `AMIGA PORT`)

- **Platform layer.**
  - `Platform/E9Platform.h` replaces `<windows.h>` on non-Windows builds and provides endian helpers.
  - `Platform/E9PlatformCommon.cpp` has the .ini reader/writer, path conversion
    (`Data\x` -> `Data/x`, `..\` -> `/`) and the Win32 calls used by the script libraries.
  - `Platform/amiga/*` is the OS layer. `E9PlatformAmiga.c` sees only OS headers;
    `E9PlatformAmigaGlue.cpp` sees only engine headers. `E9AmigaBridge.h` connects them, because the two
    sets of headers collide (BOOL, WORD, LONG, DeleteFile...).
  - `Platform/posix/*` is the headless PC test platform.
- **New portable back-ends.**
  - `Engine/Render/R9RenderSW.*` is a software renderer. It covers modulate, the six blend modes,
    alpha-replicate text, view flip/offset, wrap/clamp and render targets, with fast paths for plain sprites.
  - `Engine/Sound/A9AudioSW.*` is a software mixer driven from `A9_Update`.
  - `E9App.cpp` has a portable main loop, and `Game.cpp` has `main()`.
- **Big-endian fixes.**
  - Pixel access (`R9Img.h`), TGA headers, font files, PAK header/FAT, map chunks and brushes (`DizMap.cpp`).
  - The WAV parser, and native sample order for WAV/OGG output.
  - ZIP archives are refused on big-endian builds; games use .pak or folders.
- **Bugs that MSVC/Windows tolerated but other systems don't.**
  - `sassert` expanded to an empty statement and broke `if/else`.
  - Overlapping `memcpy` calls in the script lexer and the key queue.
  - `strcat` onto script-owned strings in TileLoad/SampleLoad/MusicLoad (heap overflow).
  - Objects were allocated with malloc and freed with `delete`.
  - `f9FileMem::Close` returned nothing.
  - `gsObj()` left half of its union uninitialised.
  - About 350 calls bound temporaries to non-const references, fixed at 15 signatures.
  - Case and backslash problems in `#include`s.
- **Windows-only features.**
  - The F1 dialog is now a requester.
  - F10 (fullscreen toggle) is disabled.
  - Script `MessageBox` shows a requester.
  - `ShellExecute`/`Launch` return 0.
  - The guard/SEH exception system is off.
