///////////////////////////////////////////////////////////////////////////////////////////////////
// R9RenderSW.cpp  (AMIGA PORT)
// Software renderer - see R9RenderSW.h
//
// Semantics copied from R9RenderGL:
//   texture env MODULATE:  src = texel * vertexcolor (per channel, alpha too); no texture: src = color
//   ALPHAREP (GL_COMBINE):  src.rgb = color.rgb * texel.a ; src.a = texel.a * color.a
//   blend OPAQUE  (ONE,ZERO)                 dst = src
//         ALPHA   (SRC_ALPHA,1-SRC_ALPHA)   dst = src*a + dst*(1-a)
//         ADD     (ONE,ONE)                  dst = src + dst
//         MOD     (DST_COLOR,ZERO)           dst = src * dst
//         MOD2    (DST_COLOR,SRC_COLOR)      dst = 2 * src * dst
//   sampling: nearest (the game turns filtering off), wrap or clamp addressing
///////////////////////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "R9RenderSW.h"
#include "R9ImgLoader.h"

#define SWTEX(t)	((r9TextureSW*)((t)->m_handler))

static inline int	iceil( float f )				{ int i=(int)f; return (f>(float)i) ? i+1 : i; } // for f>=-big
static inline int	pixstart( float f )				{ return iceil(f-0.5f); }		// first pixel whose center is >= f
static inline dword	mul8( dword a, dword b )		{ dword x=a*b+128; return (x+(x>>8))>>8; }	// a*b/255

static inline dword Modulate( dword t, dword c )
{
	return	(mul8(t>>24,c>>24)<<24) |
			(mul8((t>>16)&255,(c>>16)&255)<<16) |
			(mul8((t>>8)&255,(c>>8)&255)<<8) |
			 mul8(t&255,c&255);
}

static inline dword AlphaRep( dword t, dword c )
{
	dword ta = t>>24;
	return	(mul8(ta,c>>24)<<24) |
			(mul8(ta,(c>>16)&255)<<16) |
			(mul8(ta,(c>>8)&255)<<8) |
			 mul8(ta,c&255);
}

static inline dword BlendAlpha( dword d, dword s )
{
	dword a = s>>24;
	if(a==255) return s;
	if(a==0) return d;
	dword ia = 255-a;
	dword r = mul8((s>>16)&255,a) + mul8((d>>16)&255,ia);
	dword g = mul8((s>>8)&255,a)  + mul8((d>>8)&255,ia);
	dword b = mul8(s&255,a)       + mul8(d&255,ia);
	return (d&0xff000000) | (r<<16) | (g<<8) | b;
}

static inline dword Blend( dword d, dword s, int mode )
{
	switch(mode)
	{
		case R9_BLEND_OPAQUE:	return s;
		case R9_BLEND_ALPHA:
		case R9_BLEND_ALPHAREP:	return BlendAlpha(d,s);
		case R9_BLEND_ADD:
		{
			dword r = ((s>>16)&255) + ((d>>16)&255); if(r>255) r=255;
			dword g = ((s>>8)&255)  + ((d>>8)&255);  if(g>255) g=255;
			dword b = (s&255)       + (d&255);       if(b>255) b=255;
			return (d&0xff000000) | (r<<16) | (g<<8) | b;
		}
		case R9_BLEND_MOD:
			return (d&0xff000000) | (mul8((s>>16)&255,(d>>16)&255)<<16) | (mul8((s>>8)&255,(d>>8)&255)<<8) | mul8(s&255,d&255);
		case R9_BLEND_MOD2:
		{
			dword r = 2*mul8((s>>16)&255,(d>>16)&255); if(r>255) r=255;
			dword g = 2*mul8((s>>8)&255,(d>>8)&255);   if(g>255) g=255;
			dword b = 2*mul8(s&255,d&255);             if(b>255) b=255;
			return (d&0xff000000) | (r<<16) | (g<<8) | b;
		}
	}
	return s;
}

// solid fill, unrolled (the clear and the border bars write ~120k pixels a frame)
static inline void Fill32( dword* p, int n, dword c )
{
	while(n>=8) { p[0]=c; p[1]=c; p[2]=c; p[3]=c; p[4]=c; p[5]=c; p[6]=c; p[7]=c; p+=8; n-=8; }
	while(n-->0) *p++ = c;
}

// floor(f*65536) without floorf: libnix's floorf is a mathieeesingbas.library call, far too slow
// for per-row use on a real 68040
static inline int Fix16Floor( float f )
{
	float g = f*65536.0f;
	int i = (int)g;
	return ((float)i>g) ? i-1 : i;
}

// Tint tables: Modulate(t,color) as four byte lookups instead of four multiplies per pixel. Games
// tint many tiles with a handful of colors (the ZX palette in Dizzy 3.5), so a small cache holds them.
#define SW_TINTS 16
struct tTint { dword color; int valid; byte a[256], r[256], g[256], b[256]; };
static tTint g_tint[SW_TINTS];
static int g_tintnext = 0;

static const tTint* GetTint( dword color )
{
	static const tTint* last = NULL; // consecutive tiles mostly share a color
	if(last && last->color==color) return last;
	for(int i=0;i<SW_TINTS;i++) if(g_tint[i].valid && g_tint[i].color==color) return last = &g_tint[i];
	tTint* t = &g_tint[g_tintnext];
	g_tintnext = (g_tintnext+1) % SW_TINTS;
	dword ca=color>>24, cr=(color>>16)&255, cg=(color>>8)&255, cb=color&255;
	for(dword x=0;x<256;x++) { t->a[x]=(byte)mul8(x,ca); t->r[x]=(byte)mul8(x,cr); t->g[x]=(byte)mul8(x,cg); t->b[x]=(byte)mul8(x,cb); }
	t->color = color;
	t->valid = 1;
	return last = t;
}

static inline dword Tint( const tTint* l, dword t )
{
	return ((dword)l->a[t>>24]<<24) | ((dword)l->r[(t>>16)&255]<<16) | ((dword)l->g[(t>>8)&255]<<8) | (dword)l->b[t&255];
}

///////////////////////////////////////////////////////////////////////////////////////////////////
r9RenderSW::r9RenderSW()
{
	m_api		= R9_API_DEFAULT;
	m_back		= NULL;
	m_surface	= NULL;
	m_sw		= 0;
	m_sh		= 0;
	m_clipx1 = m_clipy1 = m_clipx2 = m_clipy2 = 0;
	m_tex		= NULL;
	m_target	= NULL;
	m_batchcount= 0;
	m_ready		= FALSE;
}

r9RenderSW::~r9RenderSW()
{
}

int r9RenderSW::GatherDisplayModes( r9DisplayMode* displaymode )
{
	if(displaymode)
	{
		displaymode[0].m_windowed	= 1;
		displaymode[0].m_bpp		= 32;
		displaymode[0].m_width		= 640;
		displaymode[0].m_height		= 480;
		displaymode[0].m_refresh	= 0;
		displaymode[0].m_reserved1	= 0;
	}
	return 1;
}

BOOL r9RenderSW::Init( HWND hwnd, r9Cfg* cfg )
{
	guard(r9RenderSW::Init);
	m_hwnd = hwnd;
	if(cfg) m_cfg = *cfg;
	if(m_cfg.m_width<64)	m_cfg.m_width = 320;
	if(m_cfg.m_height<64)	m_cfg.m_height = 240;
	m_cfg.m_bpp = 32;
	dlog(LOGRND,"Software render init %ix%i\n",m_cfg.m_width,m_cfg.m_height);

	m_back = (dword*)smalloc(m_cfg.m_width*m_cfg.m_height*4);
	if(!m_back) return FALSE;
	memset(m_back,0,m_cfg.m_width*m_cfg.m_height*4);
	m_surface = m_back;
	m_sw = m_cfg.m_width;
	m_sh = m_cfg.m_height;

	if(!e9_video_open(m_cfg.m_width,m_cfg.m_height))
	{
		dlog(LOGERR,"RENDER: can't open display %ix%i\n",m_cfg.m_width,m_cfg.m_height);
		sfree(m_back); m_back=NULL;
		return FALSE;
	}

	m_ready = TRUE;
	SetDefaultStates();
	if(!CreateFont()) dlog(LOGERR,"RENDER: can't create debug font\n");
	return TRUE;
	unguard();
}

void r9RenderSW::Done()
{
	guard(r9RenderSW::Done);
	r9Render::Done(); // font
	if(m_ready) e9_video_close();
	m_ready = FALSE;
	if(m_back) sfree(m_back);
	m_back = m_surface = NULL;
	unguard();
}

BOOL r9RenderSW::IsReady() { return m_ready; }

///////////////////////////////////////////////////////////////////////////////////////////////////
// textures
///////////////////////////////////////////////////////////////////////////////////////////////////
R9TEXTURE r9RenderSW::TextureCreate( r9Img* img )
{
	guard(r9RenderSW::TextureCreate);
	if(img==NULL || !R9_ImgIsValid(img)) return NULL;
	int spp = R9_PFSpp(img->m_pf);
	if(spp!=3 && spp!=4) return NULL; // same restriction as the GL renderer

	int w = img->m_width, h = img->m_height;
	r9TextureSW* st = snew r9TextureSW;
	st->m_w = w; st->m_h = h;
	st->m_data = (dword*)smalloc(w*h*4);
	if(!st->m_data) { sdelete(st); return NULL; }

	// image bytes are in PC order: B,G,R(,A)  (see R9_PFGetDWORD)
	int opaque=1, colorkey=1;
	byte* s = img->m_data;
	dword* d = st->m_data;
	for(int i=0;i<w*h;i++)
	{
		dword a = (spp==4) ? s[3] : 255;
		*d++ = (a<<24) | ((dword)s[2]<<16) | ((dword)s[1]<<8) | (dword)s[0];
		if(a!=255) { opaque=0; if(a!=0) colorkey=0; }
		s += spp;
	}
	st->m_alphatype = opaque ? 0 : (colorkey ? 1 : 2);

	r9Texture* tex		= snew r9Texture;
	tex->m_width		= w;
	tex->m_height		= h;
	tex->m_realwidth	= w;	// no power of two padding needed in software
	tex->m_realheight	= h;
	tex->m_handler		= st;
	tex->m_handlerex	= NULL;
	return tex;
	unguard();
}

R9TEXTURE r9RenderSW::TextureCreateTarget( int width, int height )
{
	guard(r9RenderSW::TextureCreateTarget);
	r9TextureSW* st = snew r9TextureSW;
	st->m_w = width; st->m_h = height;
	st->m_alphatype = 0;
	st->m_data = (dword*)smalloc(width*height*4);
	if(!st->m_data) { sdelete(st); return NULL; }
	memset(st->m_data,0,width*height*4);
	r9Texture* tex		= snew r9Texture;
	tex->m_width		= width;
	tex->m_height		= height;
	tex->m_realwidth	= width;
	tex->m_realheight	= height;
	tex->m_handler		= st;
	tex->m_handlerex	= (void*)1; // mark as target
	return tex;
	unguard();
}

void r9RenderSW::TextureDestroy( R9TEXTURE texture )
{
	guard(r9RenderSW::TextureDestroy);
	if(texture==NULL) return;
	if(texture==m_texture) { m_texture=NULL; m_tex=NULL; }
	r9TextureSW* st = SWTEX(texture);
	if(st) { if(st->m_data) sfree(st->m_data); sdelete(st); }
	sdelete(texture);
	unguard();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// states
///////////////////////////////////////////////////////////////////////////////////////////////////
void r9RenderSW::SetTexture( R9TEXTURE texture )
{
	m_texture = texture;
	m_tex = texture ? SWTEX(texture) : NULL;
}

void r9RenderSW::SetState( int state, int value )
{
	if(state<0 || state>=R9_STATES) return;
	m_state[state] = value;
}

void r9RenderSW::UpdateClip()
{
	m_clipx1 = (int)m_viewport.x1; if(m_clipx1<0) m_clipx1=0;
	m_clipy1 = (int)m_viewport.y1; if(m_clipy1<0) m_clipy1=0;
	m_clipx2 = (int)m_viewport.x2; if(m_clipx2>m_sw) m_clipx2=m_sw;
	m_clipy2 = (int)m_viewport.y2; if(m_clipy2>m_sh) m_clipy2=m_sh;
	if(m_viewport.x2<=m_viewport.x1 || m_viewport.y2<=m_viewport.y1) { m_clipx1=0; m_clipy1=0; m_clipx2=m_sw; m_clipy2=m_sh; }
}

void r9RenderSW::SetViewport( fRect rect )
{
	m_viewport = rect;
	UpdateClip();
}

void r9RenderSW::SetView( int x, int y, dword flip )
{
	m_viewx = x;
	m_viewy = y;
	m_viewflip = flip;
}

// same mapping the GL renderer gets from glOrtho(viewport +/- view offset, flipped)
void r9RenderSW::Transform( r9Vertex& v )
{
	if(m_viewflip & R9_FLIPX)	v.x = m_viewport.x1 + m_viewport.x2 + m_viewx - v.x;
	else						v.x = v.x - m_viewx;
	if(m_viewflip & R9_FLIPY)	v.y = m_viewport.y1 + m_viewport.y2 + m_viewy - v.y;
	else						v.y = v.y - m_viewy;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// flow
///////////////////////////////////////////////////////////////////////////////////////////////////
void r9RenderSW::Clear( dword color )
{
	if(!m_surface) return;
	int n = m_sw*m_sh;
	E9_PROF_COUNT(E9_PROF_PX_FILL,n);
	Fill32(m_surface,n,color);
}

BOOL r9RenderSW::BeginScene( R9TEXTURE target )
{
	if( m_beginendscene ) return FALSE;
	m_primitivecount = 0;
	if(target && SWTEX(target))
	{
		m_target	= target;
		m_surface	= SWTEX(target)->m_data;
		m_sw		= SWTEX(target)->m_w;
		m_sh		= SWTEX(target)->m_h;
	}
	else
	{
		m_target	= NULL;
		m_surface	= m_back;
		m_sw		= m_cfg.m_width;
		m_sh		= m_cfg.m_height;
	}
	UpdateClip();
	m_beginendscene = TRUE;
	return TRUE;
}

void r9RenderSW::EndScene()
{
	if( !m_beginendscene ) return;
	m_beginendscene = FALSE;
	m_target	= NULL;
	m_surface	= m_back;
	m_sw		= m_cfg.m_width;
	m_sh		= m_cfg.m_height;
	UpdateClip();
}

void r9RenderSW::Present()
{
	if(m_ready) e9_video_present(m_back,m_cfg.m_width,m_cfg.m_height);
}

void r9RenderSW::Flush()
{
	m_needflush = FALSE; // primitives are drawn immediately in Push
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// rasterization
///////////////////////////////////////////////////////////////////////////////////////////////////
void r9RenderSW::Push( r9Vertex* vx, int vxs, int primitive )
{
	if(!m_surface) return;
	r9Vertex v[6];
	if(primitive==R9_PRIMITIVE_LINE)
	{
		for(int i=0;i+2<=vxs;i+=2)
		{
			v[0]=vx[i]; v[1]=vx[i+1];
			Transform(v[0]); Transform(v[1]);
			DrawLineSW(v);
			m_primitivecount++;
		}
		return;
	}
	int i=0;
	while(i+6<=vxs)
	{
		for(int k=0;k<6;k++) { v[k]=vx[i+k]; Transform(v[k]); }
		if(!DrawQuadAA(v)) { DrawTriangleSW(v); DrawTriangleSW(v+3); }
		m_primitivecount+=2;
		i+=6;
	}
	while(i+3<=vxs)
	{
		for(int k=0;k<3;k++) { v[k]=vx[i+k]; Transform(v[k]); }
		DrawTriangleSW(v);
		m_primitivecount++;
		i+=3;
	}
}

// Unscaled, unrotated sprites at integer positions (map tiles, most game sprites) skip the float
// setup of r9Render::DrawSprite + DrawQuadAA: one texel per pixel, so clipping and the texel mapping
// can be done with integers. Same pixels as the general path; anything else goes through it.
static inline BOOL IsInt( float f, int& i ) { i = (int)f; return (float)i==f; }

void r9RenderSW::DrawSprite( fV2& pos, fRect& src, R9TEXTURE tex, dword color, dword flip, float scale )
{
	int x, y, sx1, sy1, sx2, sy2;
	if( !tex || (flip & R9_FLIPR) || scale!=1.0f || m_viewflip ||
		!IsInt(pos.x,x) || !IsInt(pos.y,y) || !IsInt(src.x1,sx1) || !IsInt(src.y1,sy1) || !IsInt(src.x2,sx2) || !IsInt(src.y2,sy2) ||
		sx2<=sx1 || sy2<=sy1 )
	{
		r9Render::DrawSprite(pos,src,tex,color,flip,scale);
		return;
	}

	// destination in game space, clipped by the clipping rect (what ClipQuad does)
	int x1 = x, y1 = y, x2 = x+(sx2-sx1), y2 = y+(sy2-sy1);
	if(IsClipping())
	{
		int cx1, cy1, cx2, cy2;
		if( !IsInt(m_cliprect.x1,cx1) || !IsInt(m_cliprect.y1,cy1) || !IsInt(m_cliprect.x2,cx2) || !IsInt(m_cliprect.y2,cy2) )
		{
			r9Render::DrawSprite(pos,src,tex,color,flip,scale);
			return;
		}
		if(x1<cx1) x1=cx1;
		if(y1<cy1) y1=cy1;
		if(x2>cx2) x2=cx2;
		if(y2>cy2) y2=cy2;
	}
	if(x1>=x2 || y1>=y2) return;

	if(GetTexture()!=tex) SetTexture(tex);
	if(!m_surface || !m_tex) return;
	m_primitivecount += 2;

	// view offset, then the scissor (what Transform and DrawQuadAA do)
	int px1 = x1-m_viewx, py1 = y1-m_viewy, px2 = x2-m_viewx, py2 = y2-m_viewy;
	if(px1<m_clipx1) px1=m_clipx1;
	if(py1<m_clipy1) py1=m_clipy1;
	if(px2>m_clipx2) px2=m_clipx2;
	if(py2>m_clipy2) py2=m_clipy2;
	if(px1>=px2 || py1>=py2) return;

	// texel of the first pixel, then +-1 texel per pixel/row (mirrored for flips)
	int gx = px1+m_viewx-x, gy = py1+m_viewy-y;		// offset inside the sprite
	int u = (flip & 1) ? sx2-1-gx : sx1+gx;
	int v = (flip & 2) ? sy2-1-gy : sy1+gy;
	int du = (flip & 1) ? -0x10000 : 0x10000;
	int dv = (flip & 2) ? -1 : 1;
	dword* line = m_surface + py1*m_sw + px1;
	for(int py=py1; py<py2; py++)
	{
		Span(line, px2-px1, u<<16, v<<16, du, 0, color);
		line += m_sw; v += dv;
	}
}

// Runs BODY for count pixels of one texture row, with t = the texel and dst = the pixel. When the
// step is a whole number of texels (unscaled sprites, flipped or not) it walks a pointer instead of
// shifting a 16.16 coordinate for every pixel.
#define TEXEL_LOOP(BODY)																	\
	if((du&0xffff)==0)																		\
	{																						\
		const dword* s = row + (u>>16);														\
		int sd = du>>16;																	\
		while(count--) { dword t = *s; s += sd; BODY dst++; }								\
	}																						\
	else																					\
	{																						\
		while(count--) { dword t = row[u>>16]; u += du; BODY dst++; }						\
	}

// Draws count pixels starting at dst; u,v,du,dv are 16.16 texel coordinates
void r9RenderSW::Span( dword* dst, int count, int u, int v, int du, int dv, dword color )
{
	int blend = GetState(R9_STATE_BLEND);
	if(!m_tex)
	{
		E9_PROF_COUNT(E9_PROF_PX_FILL,count);
		if(blend==R9_BLEND_OPAQUE) { Fill32(dst,count,color); return; }
		if((blend==R9_BLEND_ALPHA || blend==R9_BLEND_ALPHAREP) && (color>>24)==255) { Fill32(dst,count,color); return; } // opaque color: BlendAlpha returns it
		while(count--) { *dst = Blend(*dst,color,blend); dst++; }
		return;
	}

	int tw = m_tex->m_w, th = m_tex->m_h;
	const dword* tdata = m_tex->m_data;

	// does the whole span stay inside the texture? then no addressing work per pixel
	int ul = u>>16, ur = (u+du*(count-1))>>16;
	int vl = v>>16, vr = (v+dv*(count-1))>>16;
	BOOL inside = ul>=0 && ur>=0 && ul<tw && ur<tw && vl>=0 && vr>=0 && vl<th && vr<th;

	if(inside && color==0xffffffff && blend!=R9_BLEND_ALPHAREP)
	{
		if(blend==R9_BLEND_ALPHA || (blend==R9_BLEND_OPAQUE && m_tex->m_alphatype==0))
		{
			if(dv==0) // horizontal run in a single texture row (normal sprites, flipped x)
			{
				const dword* row = tdata + (v>>16)*tw;
				if(blend==R9_BLEND_OPAQUE || m_tex->m_alphatype==0)
				{
					E9_PROF_COUNT(E9_PROF_PX_COPY,count);
					if(du==0x10000) { memcpy(dst,row+(u>>16),count*4); return; }
					TEXEL_LOOP( *dst = t; )
					return;
				}
				if(m_tex->m_alphatype==1) // color key
				{
					E9_PROF_COUNT(E9_PROF_PX_KEY,count);
					TEXEL_LOOP( if(t&0xff000000) *dst = t; )
					return;
				}
				E9_PROF_COUNT(E9_PROF_PX_BLEND,count);
				TEXEL_LOOP( *dst = BlendAlpha(*dst,t); )
				return;
			}
			E9_PROF_COUNT(E9_PROF_PX_BLEND,count);
			while(count--) { *dst = BlendAlpha(*dst,tdata[(v>>16)*tw+(u>>16)]); dst++; u+=du; v+=dv; }
			return;
		}
	}

	// horizontal runs with a tint color or text (ALPHAREP): the common cases the paths above leave out
	if(inside && dv==0 && (blend==R9_BLEND_ALPHA || blend==R9_BLEND_OPAQUE || blend==R9_BLEND_ALPHAREP))
	{
		const dword* row = tdata + (v>>16)*tw;
		dword ca = color>>24;
		if(blend==R9_BLEND_ALPHAREP)
		{
			if(ca==255) // text: font texels are mostly fully off or fully on
			{
				E9_PROF_COUNT(E9_PROF_PX_TEXT,count);
				TEXEL_LOOP( dword ta = t>>24; if(ta==255) *dst = color; else if(ta) *dst = BlendAlpha(*dst,AlphaRep(t,color)); )
				return;
			}
		}
		else if(blend==R9_BLEND_OPAQUE && color==0xffffffff) // opaque blend of a texture that has alpha
		{
			E9_PROF_COUNT(E9_PROF_PX_COPY,count);
			TEXEL_LOOP( *dst = t; )
			return;
		}
		else
		{
			E9_PROF_COUNT(E9_PROF_PX_TINT,count);
			const tTint* l = GetTint(color);
			// white texels tint to exactly the color (when its alpha is 255): 1 bit art like the ZX
			// tiles of Dizzy 3.5 is almost all white, so this skips the table lookups for most pixels
			if(ca==255 && (blend==R9_BLEND_OPAQUE || m_tex->m_alphatype==0)) // result is opaque
			{
				TEXEL_LOOP( *dst = (t==0xffffffff) ? color : Tint(l,t); )
				return;
			}
			if(blend==R9_BLEND_OPAQUE) // opaque, color alpha below 255
			{
				TEXEL_LOOP( *dst = Tint(l,t); )
				return;
			}
			if(m_tex->m_alphatype==1 && ca==255) // color key
			{
				TEXEL_LOOP( if(t==0xffffffff) *dst = color; else if(t&0xff000000) *dst = Tint(l,t); )
				return;
			}
			TEXEL_LOOP( *dst = BlendAlpha(*dst,Tint(l,t)); )
			return;
		}
	}

	E9_PROF_COUNT(E9_PROF_PX_GENERIC,count);
	BOOL wrap = (GetState(R9_STATE_TADDRESS)!=R9_TADDRESS_CLAMP);
	while(count--)
	{
		int tu = u>>16, tv = v>>16;
		if(!inside)
		{
			if(wrap)
			{
				tu %= tw; if(tu<0) tu+=tw;
				tv %= th; if(tv<0) tv+=th;
			}
			else
			{
				if(tu<0) tu=0; else if(tu>=tw) tu=tw-1;
				if(tv<0) tv=0; else if(tv>=th) tv=th-1;
			}
		}
		dword t = tdata[tv*tw+tu];
		dword s = (blend==R9_BLEND_ALPHAREP) ? AlphaRep(t,color) : (color==0xffffffff ? t : Modulate(t,color));
		*dst = Blend(*dst,s,blend);
		dst++; u+=du; v+=dv;
	}
}

// Axis aligned rectangle made of two triangles (DrawQuad / DrawSprite / DrawBar pattern)
BOOL r9RenderSW::DrawQuadAA( r9Vertex* v )
{
	// all six vertices must use only two x values and two y values
	float xa=v[0].x, xb=v[0].x, ya=v[0].y, yb=v[0].y;
	int i;
	for(i=1;i<6;i++)
	{
		if(v[i].x!=xa && v[i].x!=xb) { if(xa==xb) xb=v[i].x; else return FALSE; }
		if(v[i].y!=ya && v[i].y!=yb) { if(ya==yb) yb=v[i].y; else return FALSE; }
		if(v[i].color!=v[0].color) return FALSE;
	}
	if(xa==xb || ya==yb) return TRUE; // degenerate, nothing to draw
	// the first triangle must span both axes from v0 (v1 along one axis, v2 along the other)
	float x0=v[0].x, y0=v[0].y;
	float ex1=v[1].x-x0, ey1=v[1].y-y0, ex2=v[2].x-x0, ey2=v[2].y-y0;
	float det = ex1*ey2 - ex2*ey1;
	if(det==0.0f) return FALSE;
	// the second triangle must be the complementary half: v4 is the corner opposite v0
	float x3 = (v[0].x==xa)?xb:xa, y3 = (v[0].y==ya)?yb:ya;
	if(v[4].x!=x3 || v[4].y!=y3) return FALSE;

	float minx = xa<xb?xa:xb, maxx = xa<xb?xb:xa;
	float miny = ya<yb?ya:yb, maxy = ya<yb?yb:ya;
	int px1 = pixstart(minx), px2 = pixstart(maxx);
	int py1 = pixstart(miny), py2 = pixstart(maxy);
	if(px1<m_clipx1) px1=m_clipx1;
	if(py1<m_clipy1) py1=m_clipy1;
	if(px2>m_clipx2) px2=m_clipx2;
	if(py2>m_clipy2) py2=m_clipy2;
	if(px1>=px2 || py1>=py2) return TRUE;

	dword color = v[0].color;
	if(!m_tex)
	{
		for(int y=py1;y<py2;y++) Span(m_surface+y*m_sw+px1,px2-px1,0,0,0,0,color);
		return TRUE;
	}

	// affine uv in texel units: u = u0 + dudx*(x-x0) + dudy*(y-y0)
	float tw=(float)m_tex->m_w, th=(float)m_tex->m_h;
	float u0=v[0].u*tw, eu1=v[1].u*tw-u0, eu2=v[2].u*tw-u0;
	float v0=v[0].v*th, ev1=v[1].v*th-v0, ev2=v[2].v*th-v0;
	float dudx = (eu1*ey2 - eu2*ey1)/det;
	float dudy = (eu2*ex1 - eu1*ex2)/det;
	float dvdx = (ev1*ey2 - ev2*ey1)/det;
	float dvdy = (ev2*ex1 - ev1*ex2)/det;

	int du = (int)(dudx*65536.0f), dv = (int)(dvdx*65536.0f);
	// texel position of the first row in 16.16, then stepped per row with integer adds (no float
	// work per row; exact for the unscaled sprites and tiles games draw)
	float cx = (float)px1+0.5f-x0, cy = (float)py1+0.5f-y0;
	int iu = Fix16Floor(u0 + dudx*cx + dudy*cy);
	int iv = Fix16Floor(v0 + dvdx*cx + dvdy*cy);
	int diu = (int)(dudy*65536.0f), div = (int)(dvdy*65536.0f);
	dword* line = m_surface+py1*m_sw+px1;
	for(int y=py1;y<py2;y++)
	{
		Span(line, px2-px1, iu, iv, du, dv, color);
		line += m_sw; iu += diu; iv += div;
	}
	return TRUE;
}

void r9RenderSW::DrawTriangleSW( r9Vertex* v )
{
	// sort by y
	r9Vertex* a=&v[0]; r9Vertex* b=&v[1]; r9Vertex* c=&v[2];
	r9Vertex* t;
	if(b->y<a->y) { t=a; a=b; b=t; }
	if(c->y<a->y) { t=a; a=c; c=t; }
	if(c->y<b->y) { t=b; b=c; c=t; }
	if(c->y==a->y) return;

	// affine uv from the original (unsorted) vertices
	float x0=v[0].x, y0=v[0].y;
	float ex1=v[1].x-x0, ey1=v[1].y-y0, ex2=v[2].x-x0, ey2=v[2].y-y0;
	float det = ex1*ey2 - ex2*ey1;
	if(det==0.0f) return;
	float tw = m_tex ? (float)m_tex->m_w : 1.0f, th = m_tex ? (float)m_tex->m_h : 1.0f;
	float u0=v[0].u*tw, eu1=v[1].u*tw-u0, eu2=v[2].u*tw-u0;
	float v0=v[0].v*th, ev1=v[1].v*th-v0, ev2=v[2].v*th-v0;
	float dudx = (eu1*ey2 - eu2*ey1)/det, dudy = (eu2*ex1 - eu1*ex2)/det;
	float dvdx = (ev1*ey2 - ev2*ey1)/det, dvdy = (ev2*ex1 - ev1*ex2)/det;
	int du = (int)(dudx*65536.0f), dv = (int)(dvdx*65536.0f);
	dword color = v[0].color;

	int py1 = pixstart(a->y), py2 = pixstart(c->y);
	if(py1<m_clipy1) py1=m_clipy1;
	if(py2>m_clipy2) py2=m_clipy2;
	for(int y=py1;y<py2;y++)
	{
		float fy = (float)y+0.5f;
		// long edge a-c
		float xl = a->x + (c->x-a->x)*(fy-a->y)/(c->y-a->y);
		float xr;
		if(fy<b->y)	{ if(b->y==a->y) continue; xr = a->x + (b->x-a->x)*(fy-a->y)/(b->y-a->y); }
		else		{ if(c->y==b->y) continue; xr = b->x + (c->x-b->x)*(fy-b->y)/(c->y-b->y); }
		if(xl>xr) { float f=xl; xl=xr; xr=f; }
		int px1 = pixstart(xl), px2 = pixstart(xr);
		if(px1<m_clipx1) px1=m_clipx1;
		if(px2>m_clipx2) px2=m_clipx2;
		if(px1>=px2) continue;
		float cx = (float)px1+0.5f-x0, cy = fy-y0;
		float fu = u0 + dudx*cx + dudy*cy;
		float fv = v0 + dvdx*cx + dvdy*cy;
		Span(m_surface+y*m_sw+px1, px2-px1, Fix16Floor(fu), Fix16Floor(fv), du, dv, color);
	}
}

void r9RenderSW::DrawLineSW( r9Vertex* v )
{
	int x0=(int)floorf(v[0].x), y0=(int)floorf(v[0].y);
	int x1=(int)floorf(v[1].x), y1=(int)floorf(v[1].y);
	int dx = abs(x1-x0), sx = x0<x1?1:-1;
	int dy = -abs(y1-y0), sy = y0<y1?1:-1;
	int err = dx+dy;
	int blend = GetState(R9_STATE_BLEND);
	dword color = v[0].color;
	for(;;)
	{
		if(x0>=m_clipx1 && x0<m_clipx2 && y0>=m_clipy1 && y0<m_clipy2)
		{
			dword* p = m_surface + y0*m_sw + x0;
			*p = Blend(*p,color,blend);
		}
		if(x0==x1 && y0==y1) break;
		int e2 = 2*err;
		if(e2>=dy) { err+=dy; x0+=sx; }
		if(e2<=dx) { err+=dx; y0+=sy; }
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// screen shots
///////////////////////////////////////////////////////////////////////////////////////////////////
static void SW_BufferToImg( const dword* src, int sw, int x, int y, int w, int h, r9Img* img )
{
	img->m_pf = R9_PF_ARGB;
	img->m_width = w;
	img->m_height = h;
	R9_ImgCreate(img);
	byte* d = img->m_data;
	for(int j=0;j<h;j++)
	{
		const dword* s = src + (y+j)*sw + x;
		for(int i=0;i<w;i++) { dword c=*s++; d[0]=(byte)c; d[1]=(byte)(c>>8); d[2]=(byte)(c>>16); d[3]=255; d+=4; }
	}
}

BOOL r9RenderSW::TakeScreenShot( r9Img* img, fRect* rect, BOOL full )
{
	if(!m_back || !img) return FALSE;
	int x=0, y=0, w=m_cfg.m_width, h=m_cfg.m_height;
	if(rect && !full)
	{
		x=(int)rect->x1; y=(int)rect->y1; w=(int)rect->Width(); h=(int)rect->Height();
		if(x<0) x=0; if(y<0) y=0;
		if(x+w>m_cfg.m_width) w=m_cfg.m_width-x;
		if(y+h>m_cfg.m_height) h=m_cfg.m_height-y;
		if(w<=0 || h<=0) return FALSE;
	}
	SW_BufferToImg(m_back,m_cfg.m_width,x,y,w,h,img);
	return TRUE;
}

BOOL r9RenderSW::SaveScreenShot( fRect* rect, BOOL full )
{
	r9Img img;
	if(!TakeScreenShot(&img,rect,full)) return FALSE;
	char file[64];
	for(int i=0;i<1000;i++)
	{
		sprintf(file,"shot%03i.tga",i);
		FILE* f = fopen(e9_hostpath(file),"rb");
		if(f) { fclose(f); continue; }
		break;
	}
	BOOL ok = R9_ImgSaveFile(file,&img);
	R9_ImgDestroy(&img);
	dlog(LOGRND,"Screenshot %s %s\n",file,ok?"saved":"failed");
	return ok;
}

BOOL r9RenderSW::CopyTargetToImage( R9TEXTURE target, r9Img* img, fRect* rect )
{
	if(!target || !img || !rect || !SWTEX(target)) return FALSE;
	r9TextureSW* st = SWTEX(target);
	int w=(int)rect->Width(), h=(int)rect->Height();
	if(w>st->m_w) w=st->m_w;
	if(h>st->m_h) h=st->m_h;
	r9Img tmp;
	SW_BufferToImg(st->m_data,st->m_w,0,0,w,h,&tmp);
	R9_ImgBitBltSafe(&tmp,0,0,w,h,img,(int)rect->x1,(int)rect->y1);
	R9_ImgDestroy(&tmp);
	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
