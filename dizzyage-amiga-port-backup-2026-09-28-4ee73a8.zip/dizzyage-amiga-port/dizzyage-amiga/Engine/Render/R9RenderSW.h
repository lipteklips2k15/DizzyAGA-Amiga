///////////////////////////////////////////////////////////////////////////////////////////////////
// R9RenderSW.h  (AMIGA PORT)
// Portable software renderer. Draws into a 32bit 0xAARRGGBB (host order) back buffer and hands it
// to the platform layer (e9_video_*) for display. Emulates the fixed function states used by the
// DirectX/OpenGL renderers: texture modulate, the six R9 blend modes, view offset/flip, viewport.
///////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef __R9RENDERSW_H__
#define __R9RENDERSW_H__

#include "R9Render.h"

#define R9_BATCHSIZE_SW		(6*64)		// vertices kept before a flush (multiple of 6 and 2)

// Platform video services (Platform/<platform>/E9Video*.cpp)
BOOL	e9_video_open( int width, int height );							// open display for a width x height back buffer
void	e9_video_close();
void	e9_video_present( const dword* argb, int width, int height );	// show a frame (0xAARRGGBB host order)

struct r9TextureSW
{
	dword*	m_data;			// width*height texels, 0xAARRGGBB
	int		m_w, m_h;
	int		m_alphatype;	// 0=all opaque, 1=only 0/255 alpha (colorkey), 2=real alpha
};

class r9RenderSW : public r9Render
{
public:
					r9RenderSW();
virtual				~r9RenderSW();

virtual	int			GatherDisplayModes( r9DisplayMode* displaymode );
virtual	BOOL		Init( HWND hwnd, r9Cfg* cfg );
virtual	void		Done();
virtual	BOOL		IsReady();

virtual	R9TEXTURE	TextureCreate( r9Img* img );
virtual	R9TEXTURE	TextureCreateTarget( int width, int height );
virtual	void		TextureDestroy( R9TEXTURE tex );

virtual	void		SetTexture( R9TEXTURE tex );
virtual void		SetState( int state, int value );
virtual	void		SetViewport( fRect rect );
virtual	void		SetView( int x, int y, dword flip );

virtual	void		Clear( dword color );
virtual	BOOL		BeginScene( R9TEXTURE target=NULL );
virtual	void		EndScene();
virtual	void		Present();

virtual	void		Push( r9Vertex* vx, int vxs, int primitive );
virtual	void		Flush();
virtual	void		DrawSprite( fV2& pos, fRect& src, R9TEXTURE tex, dword color=0xffffffff, dword flip=0, float scale=1.0f );

virtual	BOOL		SaveScreenShot( fRect* rect=NULL, BOOL full=TRUE);
virtual BOOL		TakeScreenShot( r9Img* img, fRect* rect=NULL, BOOL full=TRUE );
virtual BOOL		CopyTargetToImage( R9TEXTURE target, r9Img* img, fRect* rect );

inline	dword*		GetBackBuffer()		{ return m_back; }

protected:
		void		Transform( r9Vertex& v );								// apply view offset/flip
		void		UpdateClip();
		BOOL		DrawQuadAA( r9Vertex* v );								// axis aligned quad (6 vertices); FALSE if not one
		void		DrawTriangleSW( r9Vertex* v );							// generic triangle
		void		DrawLineSW( r9Vertex* v );
		void		Span( dword* dst, int count, int u, int v, int du, int dv, dword color ); // 16.16 texel coords

		dword*		m_back;				// back buffer (screen)
		dword*		m_surface;			// current draw surface (back buffer or target)
		int			m_sw, m_sh;			// current surface size
		int			m_clipx1, m_clipy1, m_clipx2, m_clipy2;	// scissor (viewport & surface), exclusive max
		r9TextureSW* m_tex;				// current sw texture or NULL
		R9TEXTURE	m_target;			// current render target
		r9Vertex	m_batch[R9_BATCHSIZE_SW];
		int			m_batchcount;
		BOOL		m_ready;
};

#endif
///////////////////////////////////////////////////////////////////////////////////////////////////
