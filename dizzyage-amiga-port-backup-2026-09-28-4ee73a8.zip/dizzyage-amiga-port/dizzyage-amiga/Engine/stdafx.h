//////////////////////////////////////////////////////////////////////////////////////////////////
// StdAfx.h
//////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef __STDAFX_H__
#define __STDAFX_H__

#ifdef _WIN32
#pragma warning(disable:4996)	// deprecated
#pragma warning(disable:4786)	// 'identifier' : identifier was truncated to 'number' characters in the browser information
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>
#include <eh.h>
#include <crtdbg.h>
#else
// AMIGA PORT: non-Windows builds use the compatibility layer instead of windows.h
#include "E9Platform.h"
#endif

#endif
//////////////////////////////////////////////////////////////////////////////////////////////////
