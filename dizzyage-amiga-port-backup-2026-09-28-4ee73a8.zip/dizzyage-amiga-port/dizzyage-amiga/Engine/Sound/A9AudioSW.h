///////////////////////////////////////////////////////////////////////////////////////////////////
// A9AudioSW.h  (AMIGA PORT)
// Portable software mixer. All decoding and mixing happens on the main task from A9_Update()
// (DizSound calls it every frame), so no locking is needed. Output is 16bit signed stereo in
// native byte order, handed to the platform layer (e9_audio_*), e.g. AHI on AmigaOS.
///////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef __A9AUDIOSW_H__
#define __A9AUDIOSW_H__

#include "A9Audio.h"
#include "A9Codec.h"

#define A9_SW_MAXVOICES		32			// buffers + streams mixed at once
#define A9_SW_MIXCHUNK		4096		// frames mixed per step (at least a whole platform buffer, or buffers go out part filled)
#define A9_SW_STREAMBUF		4096		// frames decoded per codec call

// Platform audio services (Platform/<platform>/E9Audio*.cpp)
BOOL	e9_audio_open( int* frequency );			// open output; may change frequency to what the device uses
void	e9_audio_close();
int		e9_audio_free();							// frames that can be written now (0 = device busy)
void	e9_audio_write( const short* stereo, int frames );

struct a9Voice
{
	a9Info		m_info;			// source format
	int			m_status;		// 1=playing
	int			m_loop;
	int			m_volume;		// dB*100 [-10000,0]
	int			m_pan;			// [-10000,10000]
	int			m_gain;			// 0..256 from volume
	unsigned	m_frac;			// 16.16 fraction of the current sample
	int			m_pos;			// current frame
	int			m_isstream;
	a9Voice()	{ m_status=0; m_loop=0; m_volume=0; m_pan=0; m_gain=256; m_frac=0; m_pos=0; m_isstream=0; }
};

struct a9BufferSW : a9Buffer
{
	a9Voice		m_voice;
	byte*		m_data;			// pcm data (native order)
	a9BufferSW() { m_data=NULL; }
};

struct a9StreamSW : a9Stream
{
	a9Voice		m_voice;
	A9CODEC		m_codec;
	byte*		m_filemem;		// precached small files (mod/xm/ym)
	int			m_filesize;
	byte*		m_buf;			// decoded pcm (A9_SW_STREAMBUF frames)
	int			m_bufcount;		// valid frames in m_buf
	int			m_position;		// stream position in frames (what the game sees)
	int			m_rendering;	// codec is in BeginRender state
	int			m_ended;		// codec reached the end (no loop)
	a9StreamSW() { m_codec=NULL; m_filemem=NULL; m_filesize=0; m_buf=NULL; m_bufcount=0; m_position=0; m_rendering=0; m_ended=0; m_voice.m_isstream=1; }
};

class a9AudioSW : public a9Audio
{
public:
					a9AudioSW();
virtual				~a9AudioSW();
virtual	int			Init( HWND hwnd );
virtual	void		Done();
virtual	int			Get( int prop );
virtual	void		Set( int prop, int val );
virtual	void		Update();

virtual	A9BUFFER	BufferCreate( char* filename, int flags = A9_FLAG_VOLUME );
virtual	A9BUFFER	BufferCreateFromMemory( a9Info* info, void* audiodata, int flags = A9_FLAG_VOLUME );
virtual	void		BufferDestroy( A9BUFFER buffer );
virtual int			BufferPlay( A9BUFFER buffer, BOOL loop=FALSE );
virtual int			BufferStop( A9BUFFER buffer );
virtual	int			BufferGet( A9BUFFER buffer, int prop );
virtual	void		BufferSet( A9BUFFER buffer, int prop, int val );
virtual	int			BufferGetPosition( A9BUFFER buffer );
virtual	void		BufferSetPosition( A9BUFFER buffer, int pos );

virtual	A9STREAM	StreamCreate( char* filename, int flags = A9_FLAG_VOLUME );
virtual	void		StreamDestroy( A9STREAM stream );
virtual int			StreamPlay( A9STREAM stream, BOOL loop=FALSE );
virtual int			StreamStop( A9STREAM stream );
virtual	int			StreamGet( A9STREAM stream, int prop );
virtual	void		StreamSet( A9STREAM stream, int prop, int val );
virtual	int			StreamGetPosition( A9STREAM stream );
virtual	void		StreamSetPosition( A9STREAM stream, int pos );

		void		Mix( short* out, int frames );		// mix all playing voices (stereo)

protected:
		int			VoiceProp( a9Voice& v, int prop );
		void		VoiceSet( a9Voice& v, int prop, int val );
		void		AddVoice( void* owner, int isstream );
		void		RemoveVoice( void* owner );
		BOOL		StreamRestart( a9StreamSW* s );
		BOOL		StreamRefill( a9StreamSW* s );
		void		MixVoice( a9Voice& v, const byte* data, int count, int* acc, int frames, a9StreamSW* s );

		void*		m_active[A9_SW_MAXVOICES];		// playing buffers/streams
		int			m_activestream[A9_SW_MAXVOICES];// 1 if m_active[i] is a stream
		int			m_activecount;
		int			m_frequency;					// output frequency
		int			m_mastervolume;					// dB*100
		int			m_mastergain;					// 0..256
		int*		m_acc;							// stereo accumulator
		short*		m_out;							// stereo output chunk
		BOOL		m_open;
};

#endif
///////////////////////////////////////////////////////////////////////////////////////////////////
