///////////////////////////////////////////////////////////////////////////////////////////////////
// A9AudioSW.cpp  (AMIGA PORT)
// Software mixer - see A9AudioSW.h
///////////////////////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "A9AudioSW.h"
#include "A9Codec_ym.h"

static int A9_DbToGain( int db ) // db*100 in [-10000,0] -> 0..256
{
	if(db>=0) return 256;
	if(db<=-10000) return 0;
	return (int)(256.0f * powf(10.0f, (float)db/2000.0f) + 0.5f);
}

a9AudioSW::a9AudioSW()
{
	m_activecount	= 0;
	m_frequency		= 22050;
	m_mastervolume	= 0;
	m_mastergain	= 256;
	m_acc			= NULL;
	m_out			= NULL;
	m_open			= FALSE;
	for(int i=0;i<A9_SW_MAXVOICES;i++) m_active[i]=NULL;
}

a9AudioSW::~a9AudioSW()
{
}

int a9AudioSW::Init( HWND hwnd )
{
	guard(a9AudioSW::Init);
	m_hwnd = hwnd;
	A9_CodecInitAll();
	int freq = m_frequency;
	if(!e9_audio_open(&freq)) { dlog(LOGSND,"AUDIO: can't open audio device\n"); A9_CodecDoneAll(); return A9_FAIL; }
	m_frequency = freq;
	a9Codec_ym::SetRate(m_frequency); // emulate YM music at the mixing rate, no wasted samples
	m_acc = (int*)smalloc(A9_SW_MIXCHUNK*2*sizeof(int));
	m_out = (short*)smalloc(A9_SW_MIXCHUNK*2*sizeof(short));
	m_open = TRUE;
	m_voices = A9_SW_MAXVOICES;
	m_hw = 0;
	m_memory = 0;
	dlog(LOGSND,"Software mixer %i Hz\n",m_frequency);
	return A9_OK;
	unguard();
}

void a9AudioSW::Done()
{
	guard(a9AudioSW::Done);
	if(m_open) e9_audio_close();
	m_open = FALSE;
	m_activecount = 0;
	if(m_acc) sfree(m_acc);
	if(m_out) sfree(m_out);
	A9_CodecDoneAll();
	unguard();
}

int a9AudioSW::Get( int prop )
{
	switch(prop)
	{
		case A9_HW:				return m_hw;
		case A9_MEMORY:			return m_memory;
		case A9_VOICES:			return m_voices;
		case A9_MASTERVOLUME:	return m_mastervolume;
	}
	return 0;
}

void a9AudioSW::Set( int prop, int val )
{
	if(prop==A9_MASTERVOLUME)
	{
		m_mastervolume = val;
		m_mastergain = A9_DbToGain(val);
	}
}

void a9AudioSW::Update()
{
	if(!m_open) return;
	for(int guardloops=0; guardloops<32; guardloops++)
	{
		int n = e9_audio_free();
		if(n<=0) break;
		if(n>A9_SW_MIXCHUNK) n=A9_SW_MIXCHUNK;
		Mix(m_out,n);
		e9_audio_write(m_out,n);
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// voices
///////////////////////////////////////////////////////////////////////////////////////////////////
void a9AudioSW::AddVoice( void* owner, int isstream )
{
	for(int i=0;i<m_activecount;i++) if(m_active[i]==owner) return;
	if(m_activecount>=A9_SW_MAXVOICES) { dlog(LOGSND,"AUDIO: too many voices\n"); return; }
	m_activestream[m_activecount] = isstream;
	m_active[m_activecount++] = owner;
}

void a9AudioSW::RemoveVoice( void* owner )
{
	for(int i=0;i<m_activecount;i++)
		if(m_active[i]==owner) { --m_activecount; m_active[i]=m_active[m_activecount]; m_activestream[i]=m_activestream[m_activecount]; return; }
}

int a9AudioSW::VoiceProp( a9Voice& v, int prop )
{
	switch(prop)
	{
		case A9_FLAGS:		return A9_FLAG_VOLUME;
		case A9_DEPTH:		return v.m_info.m_depth;
		case A9_CHANNELS:	return v.m_info.m_channels;
		case A9_FREQUENCY:	return v.m_info.m_frequency;
		case A9_SIZE:		return v.m_info.m_size;
		case A9_STATUS:		return v.m_status;
		case A9_VOLUME:		return v.m_volume;
		case A9_PAN:		return v.m_pan;
	}
	return 0;
}

void a9AudioSW::VoiceSet( a9Voice& v, int prop, int val )
{
	switch(prop)
	{
		case A9_VOLUME:	v.m_volume = val; v.m_gain = A9_DbToGain(val); break;
		case A9_PAN:	v.m_pan = val; break;
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// buffers
///////////////////////////////////////////////////////////////////////////////////////////////////
A9BUFFER a9AudioSW::BufferCreate( char* filename, int flags )
{
	guard(a9AudioSW::BufferCreate);
	A9BUFFERPROTO proto = BufferPrecache(filename);
	if(!proto) return NULL;
	A9BUFFER b = BufferCreateFromMemory(&proto->m_info,proto->m_data,flags);
	BufferDeprecache(proto);
	return b;
	unguard();
}

A9BUFFER a9AudioSW::BufferCreateFromMemory( a9Info* info, void* audiodata, int flags )
{
	guard(a9AudioSW::BufferCreateFromMemory);
	if(!info || !audiodata || info->DataSize()<=0) return NULL;
	a9BufferSW* b = snew a9BufferSW();
	b->m_info = *info;
	b->m_flags = flags;
	b->m_voice.m_info = *info;
	b->m_data = (byte*)smalloc(info->DataSize());
	if(!b->m_data) { sdelete(b); return NULL; }
	memcpy(b->m_data,audiodata,info->DataSize());
	return b;
	unguard();
}

void a9AudioSW::BufferDestroy( A9BUFFER buffer )
{
	if(!buffer) return;
	a9BufferSW* b = (a9BufferSW*)buffer;
	RemoveVoice(b);
	if(b->m_data) sfree(b->m_data);
	sdelete(b);
}

int a9AudioSW::BufferPlay( A9BUFFER buffer, BOOL loop )
{
	if(!buffer) return A9_FAIL;
	a9BufferSW* b = (a9BufferSW*)buffer;
	b->m_voice.m_loop = loop;
	b->m_voice.m_status = 1;
	AddVoice(b,0);
	return A9_OK;
}

int a9AudioSW::BufferStop( A9BUFFER buffer )
{
	if(!buffer) return A9_FAIL;
	a9BufferSW* b = (a9BufferSW*)buffer;
	b->m_voice.m_status = 0;
	RemoveVoice(b);
	return A9_OK;
}

int	 a9AudioSW::BufferGet( A9BUFFER buffer, int prop )				{ if(!buffer) return 0; if(prop==A9_USER) return buffer->m_user; return VoiceProp(((a9BufferSW*)buffer)->m_voice,prop); }
void a9AudioSW::BufferSet( A9BUFFER buffer, int prop, int val )		{ if(!buffer) return; if(prop==A9_USER) { buffer->m_user=val; return; } VoiceSet(((a9BufferSW*)buffer)->m_voice,prop,val); }
int	 a9AudioSW::BufferGetPosition( A9BUFFER buffer )				{ if(!buffer) return 0; return ((a9BufferSW*)buffer)->m_voice.m_pos; }
void a9AudioSW::BufferSetPosition( A9BUFFER buffer, int pos )		{ if(!buffer) return; a9Voice& v=((a9BufferSW*)buffer)->m_voice; if(pos<0) pos=0; if(pos>=v.m_info.m_size) pos=0; v.m_pos=pos; v.m_frac=0; }

///////////////////////////////////////////////////////////////////////////////////////////////////
// streams
///////////////////////////////////////////////////////////////////////////////////////////////////
A9STREAM a9AudioSW::StreamCreate( char* filename, int flags )
{
	guard(a9AudioSW::StreamCreate);
	if(!filename) return NULL;
	int ret;
	a9StreamSW* s = snew a9StreamSW();

	// precache small music files in memory (same as the DirectX version)
	int codectype = A9_CodecFind(filename);
	if(codectype==-1) { sdelete(s); return NULL; }
	if(codectype!=A9_CODEC_WAV && codectype!=A9_CODEC_OGG)
	{
		F9FILE f = F9_FileOpen(filename);
		if(f)
		{
			F9_FileSeek(f,0,2);
			s->m_filesize = F9_FileTell(f);
			F9_FileSeek(f,0,0);
			s->m_filemem = (byte*)smalloc(s->m_filesize);
			if(s->m_filemem && F9_FileRead(s->m_filemem,s->m_filesize,f)==s->m_filesize)
			{
				char* name = file_path2file(filename);
				char* memname = F9_MakeFileName(name,s->m_filemem,s->m_filesize);
				if(memname) filename = memname;
			}
			F9_FileClose(f);
		}
	}

	s->m_codec = A9_CodecCreate(codectype);
	if(!s->m_codec) goto error;
	ret = A9_CodecOpen(s->m_codec,filename);
	if(ret!=A9_OK) goto error;

	s->m_voice.m_info = *A9_CodecGetInfo(s->m_codec);
	if(s->m_voice.m_info.SampleSize()<=0) goto error;
	dlog(LOGSND,"AUDIO: stream %s: codec %i, %i Hz, %i bit, %i ch\n",file_path2file(filename),codectype,s->m_voice.m_info.m_frequency,s->m_voice.m_info.m_depth,s->m_voice.m_info.m_channels);
	s->m_buf = (byte*)smalloc(A9_SW_STREAMBUF*s->m_voice.m_info.SampleSize());
	if(!s->m_buf) goto error;
	return s;

	error:
	if(s->m_codec) { A9_CodecClose(s->m_codec); A9_CodecDestroy(s->m_codec); }
	if(s->m_filemem) sfree(s->m_filemem);
	sdelete(s);
	return NULL;
	unguard();
}

void a9AudioSW::StreamDestroy( A9STREAM stream )
{
	if(!stream) return;
	a9StreamSW* s = (a9StreamSW*)stream;
	RemoveVoice(s);
	if(s->m_codec)
	{
		if(s->m_rendering) A9_CodecEndRender(s->m_codec);
		A9_CodecClose(s->m_codec);
		A9_CodecDestroy(s->m_codec);
	}
	if(s->m_buf) sfree(s->m_buf);
	if(s->m_filemem) sfree(s->m_filemem);
	sdelete(s);
}

BOOL a9AudioSW::StreamRestart( a9StreamSW* s )
{
	if(s->m_rendering) { A9_CodecEndRender(s->m_codec); s->m_rendering=0; }
	int size = s->m_voice.m_info.m_size;
	if(size>0) s->m_position %= size; else s->m_position = 0;
	if(A9_CodecBeginRender(s->m_codec,s->m_position,s->m_voice.m_loop)!=A9_OK) return FALSE;
	s->m_rendering = 1;
	s->m_ended = 0;
	s->m_bufcount = 0;
	s->m_voice.m_pos = 0;
	s->m_voice.m_frac = 0;
	return StreamRefill(s);
}

BOOL a9AudioSW::StreamRefill( a9StreamSW* s )
{
	if(!s->m_rendering || s->m_ended) return FALSE;
	E9_PROF_BEGIN(E9_PROF_DECODE);
	int ret = A9_CodecRender(s->m_codec,s->m_buf,A9_SW_STREAMBUF);
	E9_PROF_END(E9_PROF_DECODE);
	if(ret<=0) { s->m_ended=1; s->m_bufcount=0; return FALSE; }
	s->m_bufcount = ret;
	if(ret<A9_SW_STREAMBUF && !s->m_voice.m_loop) s->m_ended=1; // last block
	return TRUE;
}

int a9AudioSW::StreamPlay( A9STREAM stream, BOOL loop )
{
	if(!stream) return A9_FAIL;
	a9StreamSW* s = (a9StreamSW*)stream;
	if(s->m_voice.m_status && s->m_voice.m_loop==loop) return A9_OK;
	s->m_voice.m_loop = loop;
	if(!StreamRestart(s)) return A9_FAIL;
	s->m_voice.m_status = 1;
	AddVoice(s,1);
	return A9_OK;
}

int a9AudioSW::StreamStop( A9STREAM stream )
{
	if(!stream) return A9_FAIL;
	a9StreamSW* s = (a9StreamSW*)stream;
	if(s->m_voice.m_status) s->m_position += s->m_voice.m_pos; // keep position for resuming
	s->m_voice.m_status = 0;
	RemoveVoice(s);
	if(s->m_rendering) { A9_CodecEndRender(s->m_codec); s->m_rendering=0; }
	s->m_bufcount = 0;
	s->m_voice.m_pos = 0;
	return A9_OK;
}

int a9AudioSW::StreamGet( A9STREAM stream, int prop )
{
	if(!stream) return 0;
	a9StreamSW* s = (a9StreamSW*)stream;
	if(prop==A9_USER) return s->m_user;
	return VoiceProp(s->m_voice,prop);
}

void a9AudioSW::StreamSet( A9STREAM stream, int prop, int val )
{
	if(!stream) return;
	a9StreamSW* s = (a9StreamSW*)stream;
	if(prop==A9_USER) { s->m_user=val; return; }
	VoiceSet(s->m_voice,prop,val);
}

int a9AudioSW::StreamGetPosition( A9STREAM stream )
{
	if(!stream) return 0;
	a9StreamSW* s = (a9StreamSW*)stream;
	int pos = s->m_position + (s->m_voice.m_status ? s->m_voice.m_pos : 0);
	int size = s->m_voice.m_info.m_size;
	return size>0 ? pos % size : pos;
}

void a9AudioSW::StreamSetPosition( A9STREAM stream, int pos )
{
	if(!stream) return;
	a9StreamSW* s = (a9StreamSW*)stream;
	s->m_position = pos<0 ? 0 : pos;
	if(s->m_voice.m_status) StreamRestart(s);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// mixing
///////////////////////////////////////////////////////////////////////////////////////////////////
static inline void A9_ReadFrame( const byte* data, int pos, const a9Info& info, int& l, int& r )
{
	if(info.m_depth==16)
	{
		const short* p = (const short*)data + pos*info.m_channels;
		l = p[0]; r = (info.m_channels==2) ? p[1] : l;
	}
	else // 8 bit pcm is unsigned (as in DirectSound)
	{
		const byte* p = data + pos*info.m_channels;
		l = ((int)p[0]-128)<<8; r = (info.m_channels==2) ? (((int)p[1]-128)<<8) : l;
	}
}

// Mixes n output frames of a voice that stays inside its block for all of them. One loop per sample
// format, no per-sample checks. Same arithmetic as reading through A9_ReadFrame.
static void MixRun( const a9Info& info, const byte* data, int& pos, unsigned& frac, unsigned step, int gain, int* a, int n )
{
	int p = pos;
	unsigned f = frac;
	if(info.m_depth==16 && gain==256) // full volume, (x*256)>>8 == x: no multiplies (the usual case for music)
	{
		const short* d = (const short*)data;
		if(info.m_channels==2)
			while(n--) { const short* q = d + p*2; a[0] += q[0]; a[1] += q[1]; a+=2; f+=step; p+=f>>16; f&=0xffff; }
		else if(step==0x10000) // mono at the mixing rate (YM music): one source sample per output frame
		{
			const short* q = d + p;
			p += n;
			while(n--) { int x = *q++; a[0] += x; a[1] += x; a+=2; }
		}
		else
			while(n--) { int x = d[p]; a[0] += x; a[1] += x; a+=2; f+=step; p+=f>>16; f&=0xffff; }
	}
	else if(info.m_depth==16)
	{
		const short* d = (const short*)data;
		if(info.m_channels==2)
			while(n--) { const short* q = d + p*2; a[0] += (q[0]*gain)>>8; a[1] += (q[1]*gain)>>8; a+=2; f+=step; p+=f>>16; f&=0xffff; }
		else
			while(n--) { int x = (d[p]*gain)>>8; a[0] += x; a[1] += x; a+=2; f+=step; p+=f>>16; f&=0xffff; }
	}
	else // 8 bit pcm is unsigned (as in DirectSound); ((x-128)<<8)*gain>>8 == (x-128)*gain
	{
		if(info.m_channels==2)
			while(n--) { const byte* q = data + p*2; a[0] += ((int)q[0]-128)*gain; a[1] += ((int)q[1]-128)*gain; a+=2; f+=step; p+=f>>16; f&=0xffff; }
		else
			while(n--) { int x = ((int)data[p]-128)*gain; a[0] += x; a[1] += x; a+=2; f+=step; p+=f>>16; f&=0xffff; }
	}
	pos = p;
	frac = f;
}

void a9AudioSW::MixVoice( a9Voice& v, const byte* data, int count, int* acc, int frames, a9StreamSW* s )
{
	unsigned step = (unsigned)(((double)v.m_info.m_frequency*65536.0)/(double)m_frequency);
	if(step==0) step = 1;
	int gain = v.m_gain;
	int i = 0;
	while(i<frames)
	{
		if(v.m_pos>=count)
		{
			if(s) // stream: fetch next block
			{
				v.m_pos -= count;
				s->m_position += count;
				if(s->m_ended || !StreamRefill(s)) { v.m_status=0; return; }
				data = s->m_buf; count = s->m_bufcount;
				if(v.m_pos>=count) { v.m_status=0; return; }
			}
			else if(v.m_loop) { v.m_pos %= count; }
			else { v.m_status=0; v.m_pos=0; return; }
		}
		// output frames that still read inside this block: frame k reads pos + (frac + k*step)>>16
		unsigned long long room = ((unsigned long long)(count - v.m_pos) << 16) - v.m_frac;
		int n = (int)((room + step - 1) / step);
		if(n > frames-i) n = frames-i;
		if(gain)
			MixRun(v.m_info,data,v.m_pos,v.m_frac,step,gain,acc+i*2,n);
		else // silent: only advance
		{
			unsigned long long adv = (unsigned long long)v.m_frac + (unsigned long long)step*n;
			v.m_pos += (int)(adv>>16);
			v.m_frac = (unsigned)(adv & 0xffff);
		}
		i += n;
	}
}

void a9AudioSW::Mix( short* out, int frames )
{
	int* acc = m_acc;
	memset(acc,0,frames*2*sizeof(int));
	for(int i=0;i<m_activecount;i++)
	{
		if(m_activestream[i])
		{
			a9StreamSW* s = (a9StreamSW*)m_active[i];
			if(s->m_voice.m_status) MixVoice(s->m_voice,s->m_buf,s->m_bufcount,acc,frames,s);
		}
		else
		{
			a9BufferSW* b = (a9BufferSW*)m_active[i];
			if(b->m_voice.m_status) MixVoice(b->m_voice,b->m_data,b->m_info.m_size,acc,frames,NULL);
		}
	}
	// drop voices that finished
	for(int i=0;i<m_activecount;)
	{
		a9Voice* v = m_activestream[i] ? &((a9StreamSW*)m_active[i])->m_voice : &((a9BufferSW*)m_active[i])->m_voice;
		if(!v->m_status) { --m_activecount; m_active[i]=m_active[m_activecount]; m_activestream[i]=m_activestream[m_activecount]; }
		else i++;
	}
	int mg = m_mastergain;
	if(mg==256) // full master volume: only clip
	{
		for(int i=0;i<frames*2;i++)
		{
			int x = acc[i];
			if(x>32767) x=32767; else if(x<-32768) x=-32768;
			out[i] = (short)x;
		}
		return;
	}
	for(int i=0;i<frames*2;i++)
	{
		int x = (acc[i]*mg)>>8;
		if(x>32767) x=32767; else if(x<-32768) x=-32768;
		out[i] = (short)x;
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
