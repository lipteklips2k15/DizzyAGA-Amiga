///////////////////////////////////////////////////////////////////////////////////////////////////
// E9PlatformPosix.cpp  (AMIGA PORT - host test platform)
// Headless: runs the game for a number of frames with scripted key presses, saves selected frames
// as PPM images and the audio output as a WAV file. Used to verify the portable engine on a PC.
//
// usage: dizzy [frames] [shotevery] [keyscript]
//   keyscript: "frame:key:down,frame:key:up,..." with DirectInput key codes (e.g. 200=up, 57=space)
///////////////////////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "E9System.h"
#include "D9Debug.h"
#include "I9Input.h"
#include <sys/time.h>
#include <unistd.h>
#include <sys/stat.h>
#include <dirent.h>

static int		g_frames		= 600;
static int		g_shotevery		= 100;
static int		g_frame			= 0;
static char		g_keyscript[1024] = "";
static unsigned	g_fakeclock		= 0;		// deterministic time: 1000/36 ms per frame

void e9_platform_args( int argc, char** argv )
{
	if(argc>1) g_frames = atoi(argv[1]);
	if(argc>2) g_shotevery = atoi(argv[2]);
	if(argc>3) strncpy(g_keyscript,argv[3],1023);
}

unsigned int	e9_platform_ticks()						{ return g_fakeclock; }
unsigned int	e9_platform_uticks()					{ return g_fakeclock*1000; }
void			e9_platform_sleep( unsigned int ms )	{ }
void			e9_platform_msgbox( const char* text, const char* caption ) { fprintf(stderr,"[MSGBOX %s]\n%s\n",caption,text); }
void			e9_platform_debugout( const char* msg )	{ fputs(msg,stderr); }
const char*		e9_platform_exename()					{ return "dizzy"; }

BOOL e9_platform_init()	{ return TRUE; }
void e9_platform_done()	{ }

///////////////////////////////////////////////////////////////////////////////////////////////////
// input: scripted keys
///////////////////////////////////////////////////////////////////////////////////////////////////
class i9InputPosix : public i9Input
{
public:
	BOOL	m_kbd;
	i9InputPosix() { m_kbd=FALSE; }
	virtual BOOL DeviceInit( int device )		{ if(device==I9_DEVICE_KEYBOARD) { m_kbd=TRUE; return TRUE; } return FALSE; }
	virtual void DeviceDone( int device )		{ if(device==I9_DEVICE_KEYBOARD) m_kbd=FALSE; }
	virtual BOOL DeviceIsPresent( int device )	{ return device==I9_DEVICE_KEYBOARD && m_kbd; }
	virtual void DeviceUpdate( int device )
	{
		if(device!=I9_DEVICE_KEYBOARD) return;
		// apply script events for this frame
		char* p = g_keyscript;
		while(*p)
		{
			int f=0,k=0; char state[8]="";
			if(sscanf(p,"%d:%d:%7[a-z]",&f,&k,state)==3 && f==g_frame && k>0 && k<256)
				PushKey(k, state[0]=='d');
			char* c = strchr(p,','); if(!c) break; p=c+1;
		}
	}
	virtual void DeviceClear( int device )		{ }
};
i9Input* I9_CreatePlatformInput() { return snew i9InputPosix(); }

///////////////////////////////////////////////////////////////////////////////////////////////////
// events / main loop hook
///////////////////////////////////////////////////////////////////////////////////////////////////
BOOL e9_platform_events( BOOL* active )
{
	g_frame++;
	g_fakeclock = (unsigned)((double)g_frame*1000.0/36.0) + 1;
	return g_frame <= g_frames;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// video
///////////////////////////////////////////////////////////////////////////////////////////////////
BOOL e9_video_open( int width, int height )	{ fprintf(stderr,"video %ix%i\n",width,height); return TRUE; }
void e9_video_close()						{ }
void e9_video_present( const dword* argb, int width, int height )
{
	if(g_shotevery<=0 || (g_frame % g_shotevery)!=0) return;
	char name[64]; sprintf(name,"frame%05d.ppm",g_frame);
	FILE* f = fopen(name,"wb"); if(!f) return;
	fprintf(f,"P6\n%d %d\n255\n",width,height);
	for(int i=0;i<width*height;i++) { dword c=argb[i]; unsigned char rgb[3]={(unsigned char)(c>>16),(unsigned char)(c>>8),(unsigned char)c}; fwrite(rgb,1,3,f); }
	fclose(f);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// audio: written to out.wav at the rate of the fake clock
///////////////////////////////////////////////////////////////////////////////////////////////////
static FILE*	g_wav = NULL;
static int		g_freq = 22050;
static unsigned	g_written = 0;
BOOL e9_audio_open( int* frequency )
{
	g_freq = *frequency;
	g_wav = fopen("out.wav","wb");
	if(!g_wav) return FALSE;
	byte h[44]; memset(h,0,44); fwrite(h,1,44,g_wav);
	return TRUE;
}
void e9_audio_close()
{
	if(!g_wav) return;
	unsigned datasize = g_written*4;
	byte h[44]; memcpy(h,"RIFF",4); e9_wrle32(h+4,36+datasize); memcpy(h+8,"WAVEfmt ",8);
	e9_wrle32(h+16,16); e9_wrle16(h+20,1); e9_wrle16(h+22,2); e9_wrle32(h+24,g_freq); e9_wrle32(h+28,g_freq*4);
	e9_wrle16(h+32,4); e9_wrle16(h+34,16); memcpy(h+36,"data",4); e9_wrle32(h+40,datasize);
	fseek(g_wav,0,SEEK_SET); fwrite(h,1,44,g_wav); fclose(g_wav); g_wav=NULL;
}
int e9_audio_free()
{
	unsigned want = (unsigned)((double)g_fakeclock*g_freq/1000.0);
	return want>g_written ? (int)(want-g_written) : 0;
}
void e9_audio_write( const short* stereo, int frames )
{
	if(!g_wav) return;
	for(int i=0;i<frames*2;i++) { byte b[2]; e9_wrle16(b,(unsigned short)stereo[i]); fwrite(b,1,2,g_wav); }
	g_written += frames;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// file system (POSIX)
///////////////////////////////////////////////////////////////////////////////////////////////////
static void trimslash( char* p ) { int n=(int)strlen(p); if(n>0 && p[n-1]=='/') p[n-1]=0; }
int CreateDirectory( const char* path, void* )		{ char p[512]; strcpy(p,e9_hostpath(path)); trimslash(p); return mkdir(p,0755)==0; }
int RemoveDirectory( const char* path )				{ char p[512]; strcpy(p,e9_hostpath(path)); trimslash(p); return rmdir(p)==0; }
DWORD GetCurrentDirectory( DWORD size, char* out )	{ if(!getcwd(out,size)) { out[0]=0; return 0; } return (DWORD)strlen(out); }
int SetCurrentDirectory( const char* path )			{ return chdir(e9_hostpath(path))==0; }

int e9_scandir( const char* dospath, e9_dircallback cb, void* user )
{
	char p[512];
	strcpy(p,e9_hostpath(dospath?dospath:""));
	trimslash(p);
	int n=(int)strlen(p);
	DIR* d = opendir(n?p:".");
	if(!d) return FALSE;
	struct dirent* e;
	while((e=readdir(d))!=NULL)
	{
		if(strcmp(e->d_name,".")==0 || strcmp(e->d_name,"..")==0) continue;
		char full[768];
		snprintf(full,sizeof(full),"%s%s%s",p,n?"/":"",e->d_name);
		struct stat st;
		int isdir = (stat(full,&st)==0) && S_ISDIR(st.st_mode);
		cb(e->d_name,isdir,user);
	}
	closedir(d);
	return TRUE;
}

int e9_fileinfo( const char* dospath, long* size, long* mtime )
{
	struct stat st;
	if(stat(e9_hostpath(dospath),&st)!=0) return FALSE;
	if(S_ISDIR(st.st_mode)) return FALSE;
	if(size) *size=(long)st.st_size;
	if(mtime) *mtime=(long)st.st_mtime;
	return TRUE;
}
