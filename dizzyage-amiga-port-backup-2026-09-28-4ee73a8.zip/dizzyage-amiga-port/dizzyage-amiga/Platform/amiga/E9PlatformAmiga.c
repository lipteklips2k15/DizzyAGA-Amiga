/*************************************************************************************************
 * E9PlatformAmiga.c  (AMIGA PORT)
 * The AmigaOS 3.x side of the DizzyAGE platform layer. Plain C, only OS headers. See E9AmigaBridge.h
 *   - startup: program dir, exe name, timer.device E-clock
 *   - video: RTG screen via the cybergraphics API (provided by Picasso96), or a 256 color AGA screen
 *   - input: IDCMP raw keys -> DirectInput scancodes, lowlevel.library joystick / CD32 pad
 *   - audio: ahi.device (2 x 1536 frame buffers, ahir_Link) or Paula via audio.device, from the main loop
 *   - file system: dos.library
 *************************************************************************************************/
#include <string.h>
#include <stdio.h>

#include <exec/exec.h>
#include <dos/dos.h>
#include <intuition/intuition.h>
#include <intuition/screens.h>
#include <graphics/gfx.h>
#include <graphics/gfxbase.h>
#include <graphics/displayinfo.h>
#include <graphics/modeid.h>
#include <stdlib.h>
#include <devices/timer.h>
#include <devices/ahi.h>
#include <devices/audio.h>
#include <devices/inputevent.h>
#include <libraries/lowlevel.h>
#include <cybergraphx/cybergraphics.h>
#include <workbench/startup.h>

#include <proto/exec.h>
#include <proto/dos.h>
#include <proto/intuition.h>
#include <proto/graphics.h>
#include <proto/timer.h>
#include <proto/lowlevel.h>
#include <proto/cybergraphics.h>

#include "E9AmigaBridge.h"

extern struct WBStartup* _WBenchMsg;	/* libnix startup */

/* libnix: stack for the script compiler (recursive) and the VM. __stack is only honoured when
   libnix's swapstack.o (which defines __stkswap) is linked, and nothing pulls it in by default,
   so reference it here - otherwise the game runs on the caller's small stack and crashes. */
unsigned long __stack = 200000;
extern void __stkswap( void );
void (*const g_force_stkswap)( void ) = __stkswap;

struct Library*			CyberGfxBase	= NULL;
struct Library*			LowLevelBase	= NULL;
struct Device*			TimerBase		= NULL;

static struct MsgPort*		g_timerport	= NULL;
static struct timerequest*	g_timerio	= NULL;
static struct EClockVal		g_eclock0;
static struct MsgPort*		g_sleepport	= NULL;
static struct timerequest*	g_sleepio	= NULL;
static int					g_sleepopen	= 0;
static ULONG				g_eclockfreq = 0;

static char					g_exename[64] = "dizzy";
static BPTR					g_oldcd = 0;
static int					g_cdchanged = 0;
static int					g_fromcli = 1;

static struct Screen*		g_screen	= NULL;
static struct Window*		g_window	= NULL;
static UWORD*				g_nopointer	= NULL;
static APTR					g_oldwinptr	= NULL;
static int					g_winptrset	= 0;
static int					g_active	= 1;
static char					g_videoinfo[96] = "";

/*************************************************************************************************
 * startup
 *************************************************************************************************/
void amiga_args( int argc, char** argv )
{
	const char* name = NULL;
	if(argc==0) /* started from Workbench (libnix: argc==0, the message is in _WBenchMsg) */
	{
		struct WBStartup* wb = (struct WBStartup*)_WBenchMsg;
		g_fromcli = 0;
		if(wb && wb->sm_NumArgs>0) name = (const char*)wb->sm_ArgList[0].wa_Name;
	}
	else if(argc>0 && argv && argv[0]) name = argv[0];

	if(name)
	{
		const char* p = name;
		const char* c;
		char* dot;
		for(c=name; *c; c++) if(*c=='/' || *c==':') p=c+1;
		strncpy(g_exename,p,63); g_exename[63]=0;
		dot = strrchr(g_exename,'.'); if(dot) *dot=0; /* "dizzy.exe" -> "dizzy" */
	}

	/* work in the program's directory: data, pak, ini and saves are relative to it */
	{
		BPTR progdir = GetProgramDir();
		if(progdir) { g_oldcd = CurrentDir(progdir); g_cdchanged = 1; }
	}

	/* clock */
	g_timerport = CreateMsgPort();
	if(g_timerport) g_timerio = (struct timerequest*)CreateIORequest(g_timerport,sizeof(struct timerequest));
	if(g_timerio && OpenDevice((CONST_STRPTR)TIMERNAME,UNIT_ECLOCK,(struct IORequest*)g_timerio,0)==0)
	{
		TimerBase = g_timerio->tr_node.io_Device;
		g_eclockfreq = ReadEClock(&g_eclock0);
	}
	/* separate request for precise short sleeps */
	g_sleepport = CreateMsgPort();
	if(g_sleepport) g_sleepio = (struct timerequest*)CreateIORequest(g_sleepport,sizeof(struct timerequest));
	if(g_sleepio && OpenDevice((CONST_STRPTR)TIMERNAME,UNIT_MICROHZ,(struct IORequest*)g_sleepio,0)==0) g_sleepopen = 1;
}

int amiga_init( void )
{
	/* optional: without an RTG system the game uses an AGA screen (see amiga_video_open) */
	CyberGfxBase = OpenLibrary((CONST_STRPTR)"cybergraphics.library",41);
	LowLevelBase = OpenLibrary((CONST_STRPTR)"lowlevel.library",40); /* optional: joystick */
	return 1;
}

void amiga_done( void )
{
	if(LowLevelBase) { CloseLibrary(LowLevelBase); LowLevelBase=NULL; }
	if(CyberGfxBase) { CloseLibrary(CyberGfxBase); CyberGfxBase=NULL; }
	if(g_sleepopen) { CloseDevice((struct IORequest*)g_sleepio); g_sleepopen=0; }
	if(g_sleepio) { DeleteIORequest((struct IORequest*)g_sleepio); g_sleepio=NULL; }
	if(g_sleepport) { DeleteMsgPort(g_sleepport); g_sleepport=NULL; }
	if(TimerBase) { CloseDevice((struct IORequest*)g_timerio); TimerBase=NULL; }
	if(g_timerio) { DeleteIORequest((struct IORequest*)g_timerio); g_timerio=NULL; }
	if(g_timerport) { DeleteMsgPort(g_timerport); g_timerport=NULL; }
	if(g_cdchanged) { CurrentDir(g_oldcd); g_cdchanged=0; }
}

unsigned int amiga_ticks( void )
{
	struct EClockVal now;
	unsigned long long t0, t1;
	if(!TimerBase || !g_eclockfreq) return 0;
	ReadEClock(&now);
	t0 = ((unsigned long long)g_eclock0.ev_hi<<32) | g_eclock0.ev_lo;
	t1 = ((unsigned long long)now.ev_hi<<32) | now.ev_lo;
	return (unsigned int)(((t1-t0)*1000ULL)/g_eclockfreq);
}

unsigned int amiga_uticks( void )
{
	struct EClockVal now;
	unsigned long long t0, t1;
	if(!TimerBase || !g_eclockfreq) return 0;
	ReadEClock(&now);
	t0 = ((unsigned long long)g_eclock0.ev_hi<<32) | g_eclock0.ev_lo;
	t1 = ((unsigned long long)now.ev_hi<<32) | now.ev_lo;
	return (unsigned int)(((t1-t0)*1000000ULL)/g_eclockfreq);
}

void amiga_sleep( unsigned int ms )
{
	if(ms==0) return;
	if(g_sleepopen)
	{
		g_sleepio->tr_node.io_Command = TR_ADDREQUEST;
		g_sleepio->tr_time.tv_secs  = ms/1000;
		g_sleepio->tr_time.tv_micro = (ms%1000)*1000;
		DoIO((struct IORequest*)g_sleepio);
	}
	else if(ms>=20) Delay(ms/20);
}

void amiga_msgbox( const char* text, const char* caption )
{
	struct EasyStruct es;
	APTR args[1];
	es.es_StructSize	= sizeof(struct EasyStruct);
	es.es_Flags			= 0;
	es.es_Title			= (UBYTE*)(caption?caption:"DizzyAGE");
	es.es_TextFormat	= (UBYTE*)"%s";
	es.es_GadgetFormat	= (UBYTE*)"OK";
	args[0] = (APTR)(text?text:"");
	EasyRequestArgs(g_window,&es,NULL,args);
}

void amiga_debugout( const char* msg )
{
	BPTR out;
	if(!g_fromcli) return;
	out = Output();
	if(out) { FPuts(out,(CONST_STRPTR)msg); Flush(out); }
}

const char* amiga_exename( void ) { return g_exename; }

const char* amiga_timer_info( void )
{
	static char sz[96];
	sprintf(sz,"eclock=%s freq=%lu sleep=%s ticks=%u",TimerBase?"open":"FAILED",(unsigned long)g_eclockfreq,g_sleepopen?"open":"FAILED",amiga_ticks());
	return sz;
}

/*************************************************************************************************
 * video
 *************************************************************************************************/
static int				g_double = 0;
static int				g_vsync = 0;
static int				g_offx = 0, g_offy = 0;
static unsigned int*	g_dblbuf = NULL;
static int				g_direct = 0;		/* present by writing into the locked screen bitmap */
static unsigned int*	g_prev = NULL;		/* the frame presented last, to skip rows that didn't change */
static int				g_prevvalid = 0;

/* 1 if row y of the frame differs from the one presented last (and remember it), 0 if unchanged.
   Most of the screen is the same from frame to frame (HUD, room, title pictures), and on real
   hardware writing to the graphics card is the slow part of presenting. */
static int RowChanged( const unsigned int* s, int y, int w )
{
	unsigned int* p;
	int x = 0;
	if(!g_prev) return 1;
	p = g_prev + y*w;
	if(g_prevvalid)
	{
		while(x+4<=w && s[x]==p[x] && s[x+1]==p[x+1] && s[x+2]==p[x+2] && s[x+3]==p[x+3]) x+=4;
		while(x<w && s[x]==p[x]) x++;
		if(x==w) return 0;
	}
	for(;x<w;x++) p[x] = s[x];
	return 1;
}

/* the screen pixel formats ConvertRow can write */
static int PixFmtDirect( ULONG pixfmt )
{
	switch(pixfmt)
	{
		case PIXFMT_RGB16: case PIXFMT_RGB16PC: case PIXFMT_RGB15: case PIXFMT_RGB15PC: case PIXFMT_BGR16PC:
		case PIXFMT_ARGB32: case PIXFMT_BGRA32: case PIXFMT_RGBA32:
			return 1;
	}
	return 0;
}

static ULONG FindMode( int w, int h, int depth )
{
	ULONG id;
	int mw, mh;
	id = BestCModeIDTags( CYBRBIDTG_NominalWidth, w, CYBRBIDTG_NominalHeight, h, CYBRBIDTG_Depth, depth, TAG_DONE );
	if(id==INVALID_ID) return INVALID_ID;
	mw = (int)GetCyberIDAttr(CYBRIDATTR_WIDTH,id);
	mh = (int)GetCyberIDAttr(CYBRIDATTR_HEIGHT,id);
	if(mw<w || mh<h) return INVALID_ID;
	if(mw>w*2 || mh>h*2) return INVALID_ID; /* would be a stamp in the middle of the screen */
	return id;
}

/*************************************************************************************************
 * AGA: a native 256 color screen for machines without RTG. The 24 bit frame is mapped to pens:
 * each color (reduced to 15 bits for the lookup) gets its own pen while there are free ones, which
 * covers games with few colors exactly; when more colors show up than pens exist, the palette is
 * rebuilt from the most frequent colors of the frame and the rest use the nearest pen.
 * WriteChunkyPixels (graphics.library V40) does the chunky to planar conversion.
 *************************************************************************************************/
static int				g_aga = 0;			/* the display is an AGA screen */
static UBYTE*			g_chunky = NULL;	/* one pen per pixel of the frame */
static UWORD*			g_penmap = NULL;	/* 15 bit color -> pen, 0xffff = not mapped yet */
static unsigned int		g_pal[256];			/* 0x00RRGGBB of each pen */
static int				g_pens = 0;			/* pens given out */
static int				g_palchanged = 0;	/* g_pal differs from the screen's palette */
static unsigned int		g_misses = 0;		/* colors this frame that had to use a near pen */
static unsigned int		g_lastrebuild = 0;	/* ms of the last palette rebuild */
static int				g_rebuild = 0;		/* rebuild the palette at the next present */
static unsigned int*	g_hist = NULL;		/* 15 bit color histogram for the rebuild */
static ULONG			g_rgb32[1+256*3+1];	/* LoadRGB32 table */
static volatile ULONG*	g_akiko = NULL;		/* Akiko's chunky to planar register, when it is used */

/* Akiko (CD32, some accelerators) converts chunky to planar in hardware: write 32 pixels as 8 longs to
   its register, read the 8 plane longs back. Used for rows whose position lines up with 32 pixels,
   under OwnBlitter() like graphics.library does, straight into the screen's bitplanes. */
/* graphics.library V40 sets ChunkyToPlanarPtr when it found Akiko, but only with a CD32 Kickstart;
   otherwise look for Akiko's ID ($CAFE at $B80002) like CD32 software does. $B8xxxx is in the CIA
   I/O area, which is mapped on AGA machines. */
#define AKIKO_ID	((volatile UWORD*)0xB80002)
#define AKIKO_C2P	((volatile ULONG*)0xB80038)
static volatile ULONG* FindAkiko( void )
{
	APTR p = GfxBase->ChunkyToPlanarPtr;
	if(p) return (volatile ULONG*)p;
	if(*AKIKO_ID==0xCAFE) return AKIKO_C2P;
	return NULL;
}

static void AkikoRows( int y0, int y1, int width )
{
	struct BitMap* bm = g_screen->RastPort.BitMap;
	volatile ULONG* c2p = g_akiko;
	ULONG bpr = bm->BytesPerRow;
	int y, g, p, groups = width/32;
	OwnBlitter();
	for(y=y0;y<y1;y++)
	{
		const ULONG* s = (const ULONG*)(g_chunky + y*width);
		ULONG off = (ULONG)(g_offy+y)*bpr + (ULONG)(g_offx>>3);
		for(g=0;g<groups;g++)
		{
			*c2p = s[0]; *c2p = s[1]; *c2p = s[2]; *c2p = s[3];
			*c2p = s[4]; *c2p = s[5]; *c2p = s[6]; *c2p = s[7];
			s += 8;
			for(p=0;p<8;p++) *(ULONG*)(bm->Planes[p] + off) = *c2p;
			off += 4;
		}
	}
	DisownBlitter();
}

#define KEY555(c)		( (((c)>>9)&0x7c00) | (((c)>>6)&0x03e0) | (((c)>>3)&0x001f) )
#define AGA_REBUILD_MISSES	64		/* new colors in one frame without an own pen before a rebuild */
#define AGA_REBUILD_MS		2000	/* at most one rebuild in this time */

static int NearestPen( unsigned int c )
{
	int r = (c>>16)&255, g = (c>>8)&255, b = c&255;
	int i, best = 0;
	unsigned int bestd = 0xffffffff;
	for(i=0;i<g_pens;i++)
	{
		int dr = r-(int)((g_pal[i]>>16)&255), dg = g-(int)((g_pal[i]>>8)&255), db = b-(int)(g_pal[i]&255);
		unsigned int d = (unsigned int)(dr*dr*3 + dg*dg*4 + db*db*2);
		if(d<bestd) { bestd = d; best = i; }
	}
	return best;
}

static UBYTE PenFor( unsigned int c )
{
	unsigned int k = KEY555(c);
	UWORD p = g_penmap[k];
	if(p!=0xffff) return (UBYTE)p;
	if(g_pens<256)
	{
		g_pal[g_pens] = c & 0xffffff;
		g_penmap[k] = (UWORD)g_pens;
		g_palchanged = 1;
		return (UBYTE)g_pens++;
	}
	p = (UWORD)NearestPen(c);
	g_penmap[k] = p;
	g_misses++;
	return (UBYTE)p;
}

static void AgaResetPalette( void )
{
	memset(g_penmap,0xff,32768*sizeof(UWORD));
	g_pal[0] = 0;			/* pen 0 is the border: keep it black */
	g_penmap[0] = 0;
	g_pens = 1;
	g_palchanged = 1;
}

static void AgaUploadPalette( void )
{
	int i;
	ULONG* t = g_rgb32;
	*t++ = ((ULONG)g_pens<<16) | 0;
	for(i=0;i<g_pens;i++)
	{
		*t++ = ((g_pal[i]>>16)&255) * 0x01010101UL;
		*t++ = ((g_pal[i]>>8)&255) * 0x01010101UL;
		*t++ = (g_pal[i]&255) * 0x01010101UL;
	}
	*t = 0;
	LoadRGB32(&g_screen->ViewPort,g_rgb32);
	g_palchanged = 0;
}

static int CmpHist( const void* a, const void* b )
{
	unsigned int ca = g_hist[*(const UWORD*)a], cb = g_hist[*(const UWORD*)b];
	return (ca<cb) ? 1 : (ca>cb) ? -1 : 0;
}

/* palette from the most frequent colors of this frame */
static void AgaRebuildPalette( const unsigned int* argb, int n )
{
	static UWORD keys[32768];
	unsigned int* rep;	/* a full color for each 15 bit key: the last one seen */
	int i, nkeys = 0;
	if(!g_hist) g_hist = (unsigned int*)AllocVec(32768*4*2,MEMF_ANY);
	if(!g_hist) { AgaResetPalette(); return; }
	rep = g_hist + 32768;
	memset(g_hist,0,32768*4);
	for(i=0;i<n;i++) { unsigned int k = KEY555(argb[i]); if(g_hist[k]++==0) keys[nkeys++] = (UWORD)k; rep[k] = argb[i]; }
	qsort(keys,nkeys,sizeof(UWORD),CmpHist);
	AgaResetPalette();
	for(i=0;i<nkeys && g_pens<256;i++)
	{
		if(keys[i]==0) continue; /* black is pen 0 already */
		g_pal[g_pens] = rep[keys[i]] & 0xffffff;
		g_penmap[keys[i]] = (UWORD)g_pens++;
	}
	g_lastrebuild = amiga_ticks();
}

static void AgaPresent( const unsigned int* argb, int width, int height )
{
	int y = 0, y0, x;
	if(g_rebuild) { AgaRebuildPalette(argb,width*height); g_rebuild = 0; g_prevvalid = 0; }
	g_misses = 0;
	while(y<height)
	{
		if(!RowChanged(argb+y*width,y,width)) { y++; continue; }
		y0 = y++;
		while(y<height && RowChanged(argb+y*width,y,width)) y++;
		/* map the run of changed rows to pens (runs of one color look up once) */
		{
			const unsigned int* s = argb + y0*width;
			UBYTE* d = g_chunky + y0*width;
			int n = (y-y0)*width;
			unsigned int lastc = ~s[0];
			UBYTE lastp = 0;
			for(x=0;x<n;x++) { unsigned int c = s[x]; if(c!=lastc) { lastc = c; lastp = PenFor(c); } d[x] = lastp; }
		}
		if(g_palchanged) AgaUploadPalette(); /* new pens must be set before their pixels show */
		if(g_akiko) AkikoRows(y0,y,width);
		else WriteChunkyPixels(&g_screen->RastPort,g_offx,g_offy+y0,g_offx+width-1,g_offy+y-1,g_chunky+y0*width,width);
	}
	if(g_palchanged) AgaUploadPalette();
	g_prevvalid = 1;
	if(g_misses>=AGA_REBUILD_MISSES && amiga_ticks()-g_lastrebuild>=AGA_REBUILD_MS) g_rebuild = 1;
}

static void AgaClose( void )
{
	if(g_chunky) { FreeVec(g_chunky); g_chunky = NULL; }
	if(g_penmap) { FreeVec(g_penmap); g_penmap = NULL; }
	if(g_hist) { FreeVec(g_hist); g_hist = NULL; }
	g_aga = 0;
	g_akiko = NULL;
}

/* the borderless backdrop window for input, no pointer, DOS requesters on our screen */
static int OpenGameWindow( int sw, int sh )
{
	g_window = OpenWindowTags( NULL,
		WA_CustomScreen,	(ULONG)g_screen,
		WA_Left,			0,
		WA_Top,				0,
		WA_Width,			sw,
		WA_Height,			sh,
		WA_Borderless,		TRUE,
		WA_Backdrop,		TRUE,
		WA_Activate,		TRUE,
		WA_RMBTrap,			TRUE,
		WA_NoCareRefresh,	TRUE,
		WA_SimpleRefresh,	TRUE,
		WA_IDCMP,			IDCMP_RAWKEY | IDCMP_ACTIVEWINDOW | IDCMP_INACTIVEWINDOW,
		TAG_DONE );
	if(!g_window) { CloseScreen(g_screen); g_screen=NULL; strcat(g_videoinfo," - OpenWindow failed"); return 0; }

	/* DOS requesters ("insert volume...") must open on our screen, not behind it on Workbench */
	g_oldwinptr = ((struct Process*)FindTask(NULL))->pr_WindowPtr;
	((struct Process*)FindTask(NULL))->pr_WindowPtr = g_window;
	g_winptrset = 1;

	/* hide the mouse pointer (empty sprite in chip ram) */
	g_nopointer = (UWORD*)AllocVec(16,MEMF_CHIP|MEMF_CLEAR);
	if(g_nopointer) SetPointer(g_window,g_nopointer,1,16,0,0);
	return 1;
}

static int AgaOpen( int width, int height, int akiko )
{
	ULONG modeid;
	int sw, sh;
	if(((struct Library*)GfxBase)->lib_Version<40) { sprintf(g_videoinfo,"AGA needs graphics.library v40 (OS 3.1)"); return 0; }
	if(!(GfxBase->ChipRevBits0 & GFXF_AA_ALICE)) { sprintf(g_videoinfo,"no AGA chipset"); return 0; }
	if(width>640) { sprintf(g_videoinfo,"AGA: %i pixels is too wide",width); return 0; }

	/* PAL lores (320x256) if the system has it, else NTSC with overscan; hires for wider games */
	if(ModeNotAvailable(PAL_MONITOR_ID|LORES_KEY)==0) { modeid = PAL_MONITOR_ID; sh = 256; }
	else { modeid = NTSC_MONITOR_ID; sh = 200; }
	modeid |= (width>320) ? HIRES_KEY : LORES_KEY;
	sw = (width>320) ? 640 : 320;
	if(sh<height) sh = height; /* NTSC: 240 lines is overscan */
	if(sh>283) { sprintf(g_videoinfo,"AGA: %i lines is too high",height); return 0; }
	g_offx = (sw-width)/2;
	g_offy = (sh-height)/2;
	sprintf(g_videoinfo,"AGA %s %s %ix%ix8",(modeid&MONITOR_ID_MASK)==PAL_MONITOR_ID?"PAL":"NTSC",width>320?"hires":"lores",sw,sh);

	g_chunky = (UBYTE*)AllocVec(width*height,MEMF_ANY|MEMF_CLEAR);
	g_penmap = (UWORD*)AllocVec(32768*sizeof(UWORD),MEMF_ANY);
	if(!g_chunky || !g_penmap) { AgaClose(); strcat(g_videoinfo," - out of memory"); return 0; }

	g_screen = OpenScreenTags( NULL,
		SA_DisplayID,	modeid,
		SA_Width,		sw,
		SA_Height,		sh,
		SA_Depth,		8,
		SA_Overscan,	OSCAN_VIDEO,
		SA_ShowTitle,	FALSE,
		SA_Quiet,		TRUE,
		SA_Draggable,	FALSE,
		SA_Exclusive,	TRUE,
		SA_Interleaved,	TRUE,
		SA_Type,		CUSTOMSCREEN,
		SA_Title,		(ULONG)"DizzyAGE",
		TAG_DONE );
	if(!g_screen) { AgaClose(); strcat(g_videoinfo," - OpenScreen failed"); return 0; }
	g_aga = 1;
	AgaResetPalette();
	AgaUploadPalette();
	SetRast(&g_screen->RastPort,0);
	if(!OpenGameWindow(sw,sh)) { AgaClose(); return 0; }

	/* Akiko: needs a plain 8 plane bitmap and rows that start and end on 32 pixel boundaries */
	g_akiko = NULL;
	{
		struct BitMap* bm = g_screen->RastPort.BitMap;
		volatile ULONG* c2p = akiko ? FindAkiko() : NULL;
		if(akiko && c2p && bm->Depth==8 && (width%32)==0 && (g_offx%32)==0 && (bm->BytesPerRow%4)==0 &&
		   (GetBitMapAttr(bm,BMA_FLAGS) & BMF_STANDARD))
			g_akiko = c2p;
		strcat(g_videoinfo, g_akiko ? ", Akiko c2p" : c2p ? ", Akiko found but not used" : "");
	}
	return 1;
}

static int RtgOpen( int width, int height, int depth, int dbl, unsigned int forcemode, int directpresent )
{
	ULONG modeid = INVALID_ID;
	int sw, sh, sd, needw, needh;

	g_double = dbl;
	if(!CyberGfxBase) { sprintf(g_videoinfo,"no RTG system (cybergraphics.library)"); return 0; }
	if(forcemode!=0 && forcemode!=(unsigned int)INVALID_ID) modeid = forcemode;
	else
	{
		if(!g_double) modeid = FindMode(width,height,depth);
		if(modeid==INVALID_ID) { modeid = FindMode(width*2,height*2,depth); if(modeid!=INVALID_ID) g_double=1; }
		if(modeid==INVALID_ID && depth!=32) { g_double=0; modeid = FindMode(width,height,32); }
		if(modeid==INVALID_ID && depth!=32) { modeid = FindMode(width*2,height*2,32); if(modeid!=INVALID_ID) g_double=1; }
	}
	if(modeid==INVALID_ID) { sprintf(g_videoinfo,"no RTG mode for %ix%i",width,height); return 0; }
	if(!IsCyberModeID(modeid)) { sprintf(g_videoinfo,"mode 0x%08lx is not an RTG mode",(unsigned long)modeid); return 0; }

	sw = (int)GetCyberIDAttr(CYBRIDATTR_WIDTH,modeid);
	sh = (int)GetCyberIDAttr(CYBRIDATTR_HEIGHT,modeid);
	sd = (int)GetCyberIDAttr(CYBRIDATTR_DEPTH,modeid);
	needw = width*(g_double?2:1);
	needh = height*(g_double?2:1);
	if(sw<needw || sh<needh) { sprintf(g_videoinfo,"mode 0x%08lx is too small",(unsigned long)modeid); return 0; }
	g_offx = (sw-needw)/2;
	g_offy = (sh-needh)/2;
	sprintf(g_videoinfo,"mode 0x%08lx %ix%ix%i%s",(unsigned long)modeid,sw,sh,sd,g_double?" pixel doubled":"");

	g_screen = OpenScreenTags( NULL,
		SA_DisplayID,	modeid,
		SA_Width,		sw,
		SA_Height,		sh,
		SA_Depth,		sd,
		SA_ShowTitle,	FALSE,
		SA_Quiet,		TRUE,
		SA_Draggable,	FALSE,
		SA_Type,		CUSTOMSCREEN,
		SA_Title,		(ULONG)"DizzyAGE",
		TAG_DONE );
	if(!g_screen) { strcat(g_videoinfo," - OpenScreen failed"); return 0; }
	if(!OpenGameWindow(sw,sh)) return 0;

	SetRast(&g_screen->RastPort,0);
	if(g_double)
	{
		g_dblbuf = (unsigned int*)AllocVec(width*2*height*2*4,MEMF_ANY);
		if(!g_dblbuf) { g_double=0; g_offx=(sw-width)/2; g_offy=(sh-height)/2; }
	}

	/* direct present for the pixel formats ConvertRow knows, WritePixelArray for the rest */
	{
		ULONG pixfmt = GetCyberMapAttr(g_screen->RastPort.BitMap,CYBRMATTR_PIXFMT);
		g_direct = directpresent && GetCyberMapAttr(g_screen->RastPort.BitMap,CYBRMATTR_ISCYBERGFX) && PixFmtDirect(pixfmt);
		sprintf(g_videoinfo+strlen(g_videoinfo),", pixfmt %lu, %s present",(unsigned long)pixfmt,g_direct?"direct":"WritePixelArray");
	}
	return 1;
}

/* aga: 1 = AGA screen, 0 = RTG only, -1 = RTG if there is a mode for it, else AGA */
int amiga_video_open( int width, int height, int depth, int dbl, int vsync, unsigned int forcemode, int directpresent, int aga, int akiko )
{
	char rtginfo[96] = "";
	int ok = 0;
	g_vsync = vsync;
	g_aga = 0;
	g_direct = 0;
	if(aga!=1)
	{
		ok = RtgOpen(width,height,depth,dbl,forcemode,directpresent);
		if(!ok) strcpy(rtginfo,g_videoinfo);
	}
	if(!ok && aga!=0)
	{
		ok = AgaOpen(width,height,akiko);
		if(!ok && rtginfo[0]) { char againfo[96]; strcpy(againfo,g_videoinfo); sprintf(g_videoinfo,"%.44s; %.44s",rtginfo,againfo); }
	}
	if(!ok)
	{
		char sz[192];
		sprintf(sz,"DizzyAGE can't open a display:\n%s\n\nIt needs an RTG graphics card (Picasso96 / CyberGraphX)\nor the AGA chipset.",g_videoinfo);
		amiga_msgbox(sz,"DizzyAGE");
		return 0;
	}

	/* last presented frame, for skipping unchanged rows (without it every row is presented) */
	g_prev = (unsigned int*)AllocVec(width*height*4,MEMF_ANY);
	g_prevvalid = 0;
	return 1;
}

void amiga_video_close( void )
{
	if(g_winptrset) { ((struct Process*)FindTask(NULL))->pr_WindowPtr = g_oldwinptr; g_winptrset = 0; }
	if(g_window) { if(g_nopointer) ClearPointer(g_window); CloseWindow(g_window); g_window=NULL; }
	if(g_screen) { CloseScreen(g_screen); g_screen=NULL; }
	if(g_nopointer) { FreeVec(g_nopointer); g_nopointer=NULL; }
	if(g_dblbuf) { FreeVec(g_dblbuf); g_dblbuf=NULL; }
	if(g_prev) { FreeVec(g_prev); g_prev=NULL; }
	g_prevvalid = 0;
	AgaClose();
}

const char* amiga_video_info( void ) { return g_videoinfo; }

/* ARGB -> screen pixel format converters (value as the CPU reads it from video memory) */
#define CV_RGB16(c)		( (((c)>>8)&0xf800) | (((c)>>5)&0x07e0) | (((c)>>3)&0x001f) )
#define CV_RGB15(c)		( (((c)>>9)&0x7c00) | (((c)>>6)&0x03e0) | (((c)>>3)&0x001f) )
#define CV_BGR16(c)		( (((c)<<8)&0xf800) | (((c)>>5)&0x07e0) | (((c)>>19)&0x001f) )
#define SWAP16(v)		( (((v)&0xff)<<8) | (((v)>>8)&0xff) )
#define CV_RGB16PC(c)	SWAP16(CV_RGB16(c))
#define CV_RGB15PC(c)	SWAP16(CV_RGB15(c))
#define CV_BGR16PC(c)	SWAP16(CV_BGR16(c))
#define CV_ARGB32(c)	(c)
#define CV_BGRA32(c)	( ((c)>>24) | (((c)>>8)&0xff00) | (((c)<<8)&0xff0000) | ((c)<<24) )
#define CV_RGBA32(c)	( ((c)<<8) | ((c)>>24) )

/* 16 bit rows are written two pixels per long, doubled rows write each pixel twice */
#define ROW16(CV)	{																	\
	ULONG* o = (ULONG*)d;															\
	if(!dbl) { for(x=0;x+1<w;x+=2) *o++ = (CV(s[x])<<16) | CV(s[x+1]);				\
			   if(x<w) *(UWORD*)o = (UWORD)CV(s[x]); }							\
	else	 { for(x=0;x<w;x++) { ULONG v = CV(s[x]); *o++ = (v<<16) | v; } }		\
	return 1; }
#define ROW32(CV)	{																	\
	ULONG* o = (ULONG*)d;															\
	if(!dbl) { for(x=0;x<w;x++) *o++ = CV(s[x]); }									\
	else	 { for(x=0;x<w;x++) { ULONG v = CV(s[x]); o[0]=v; o[1]=v; o+=2; } }		\
	return 1; }

/* converts one row into video memory; returns 0 for pixel formats it doesn't know */
static int ConvertRow( ULONG pixfmt, const unsigned int* s, UBYTE* d, int w, int dbl )
{
	int x;
	switch(pixfmt)
	{
		case PIXFMT_RGB16:		ROW16(CV_RGB16)
		case PIXFMT_RGB16PC:	ROW16(CV_RGB16PC)
		case PIXFMT_RGB15:		ROW16(CV_RGB15)
		case PIXFMT_RGB15PC:	ROW16(CV_RGB15PC)
		case PIXFMT_BGR16PC:	ROW16(CV_BGR16PC)
		case PIXFMT_ARGB32:		ROW32(CV_ARGB32)
		case PIXFMT_BGRA32:		ROW32(CV_BGRA32)
		case PIXFMT_RGBA32:		ROW32(CV_RGBA32)
	}
	return 0;
}

/* Writes the frame straight into the locked screen bitmap in its own pixel format. Much faster than
   WritePixelArray(RECTFMT_ARGB), which converts every pixel in a generic loop. */
static int PresentDirect( const unsigned int* argb, int width, int height )
{
	APTR base = NULL;
	ULONG bpr = 0, pixfmt = 0, bpp = 0;
	APTR lock;
	int y, dbl = (g_double && g_dblbuf) ? 1 : 0;
	UBYTE* row;
	if(g_direct==0) return 0;
	lock = LockBitMapTags( g_screen->RastPort.BitMap, LBMI_BASEADDRESS, (ULONG)&base, LBMI_BYTESPERROW, (ULONG)&bpr,
						   LBMI_PIXFMT, (ULONG)&pixfmt, LBMI_BYTESPERPIX, (ULONG)&bpp, TAG_DONE );
	if(!lock) return 0;
	row = (UBYTE*)base + g_offy*bpr + g_offx*bpp;
	for(y=0;y<height;y++)
	{
		const unsigned int* s = argb + y*width;
		if(!RowChanged(s,y,width)) { row += dbl ? bpr*2 : bpr; continue; }
		if(!ConvertRow(pixfmt,s,row,width,dbl)) { UnLockBitMap(lock); g_direct = 0; g_prevvalid = 0; return 0; }
		row += bpr;
		if(dbl) { ConvertRow(pixfmt,s,row,width,1); row += bpr; }
	}
	UnLockBitMap(lock);
	g_prevvalid = 1;
	return 1;
}

void amiga_video_present( const unsigned int* argb, int width, int height )
{
	int y = 0, y0;
	if(!g_window) return;
	if(g_vsync) WaitTOF();
	if(g_aga) { AgaPresent(argb,width,height); return; }
	if(PresentDirect(argb,width,height)) return;

	/* WritePixelArray for each run of changed rows */
	while(y<height)
	{
		if(!RowChanged(argb+y*width,y,width)) { y++; continue; }
		y0 = y++;
		while(y<height && RowChanged(argb+y*width,y,width)) y++;
		if(g_double && g_dblbuf)
		{
			int w2 = width*2, x, yy;
			for(yy=y0;yy<y;yy++)
			{
				const unsigned int* s = argb + yy*width;
				unsigned int* d0 = g_dblbuf + (yy*2)*w2;
				unsigned int* d = d0;
				for(x=0;x<width;x++) { unsigned int c=*s++; d[0]=c; d[1]=c; d+=2; }
				CopyMemQuick(d0,d0+w2,w2*4);
			}
			WritePixelArray((APTR)(g_dblbuf+y0*2*w2),0,0,w2*4,&g_screen->RastPort,g_offx,g_offy+y0*2,w2,(y-y0)*2,RECTFMT_ARGB);
		}
		else
		{
			/* 0xAARRGGBB words on a big-endian CPU are the bytes A,R,G,B = RECTFMT_ARGB */
			WritePixelArray((APTR)(argb+y0*width),0,0,width*4,&g_screen->RastPort,g_offx,g_offy+y0,width,y-y0,RECTFMT_ARGB);
		}
	}
	g_prevvalid = 1;
}

/*************************************************************************************************
 * events / keyboard
 *************************************************************************************************/
/* Amiga raw key code -> DirectInput scancode (the codes DizzyAGE stores in its ini), 0 = unmapped */
static const unsigned char g_rawkey2dik[128] =
{
/*00*/	0x29, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x2B, 0x00, 0x52,
/*10*/	0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x00, 0x4F, 0x50, 0x51,
/*20*/	0x1E, 0x1F, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x2B, 0x00, 0x4B, 0x4C, 0x4D,
/*30*/	0x56, 0x2C, 0x2D, 0x2E, 0x2F, 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x00, 0x53, 0x47, 0x48, 0x49,
/*40*/	0x39, 0x0E, 0x0F, 0x9C, 0x1C, 0x01, 0xD3, 0x00, 0x00, 0x00, 0x4A, 0x00, 0xC8, 0xD0, 0xCD, 0xCB,
/*50*/	0x3B, 0x3C, 0x3D, 0x3E, 0x3F, 0x40, 0x41, 0x42, 0x43, 0x44, 0x00, 0x00, 0xB5, 0x37, 0x4E, 0x57,
/*60*/	0x2A, 0x36, 0x3A, 0x1D, 0x38, 0xB8, 0xDB, 0xB7, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
/*70*/	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
};
/* HELP -> F11 (fps display), Right-Amiga -> PrintScreen (screenshot) */

int amiga_events( int* active, int* keys, int maxkeys, int* nkeys )
{
	struct IntuiMessage* msg;
	*nkeys = 0;
	if(SetSignal(0L,SIGBREAKF_CTRL_C) & SIGBREAKF_CTRL_C) return 0;
	if(g_window)
	{
		while((msg=(struct IntuiMessage*)GetMsg(g_window->UserPort))!=NULL)
		{
			ULONG cls = msg->Class;
			UWORD code = msg->Code;
			ReplyMsg((struct Message*)msg);
			if(cls==IDCMP_RAWKEY)
			{
				int dik = g_rawkey2dik[code & 0x7f];
				if(dik && *nkeys<maxkeys) keys[(*nkeys)++] = dik | ((code & IECODE_UP_PREFIX) ? 0 : 0x100);
			}
			else if(cls==IDCMP_ACTIVEWINDOW)	g_active = 1;
			else if(cls==IDCMP_INACTIVEWINDOW)	g_active = 0;
		}
	}
	*active = g_active;
	if(!g_active) Delay(2); /* don't hog the CPU while in the background */
	return 1;
}

/*************************************************************************************************
 * joystick
 *************************************************************************************************/
int amiga_joy_available( void ) { return LowLevelBase!=NULL; }

unsigned int amiga_joy_read( int port, int* x, int* y )
{
	ULONG st, type;
	unsigned int b = 0;
	*x = 0; *y = 0;
	if(!LowLevelBase) return 0;
	st = ReadJoyPort(port);
	type = st & JP_TYPE_MASK;
	if(type!=JP_TYPE_JOYSTK && type!=JP_TYPE_GAMECTLR) return 0;
	if(st & JPF_JOY_LEFT)	*x = -1000;
	if(st & JPF_JOY_RIGHT)	*x =  1000;
	if(st & JPF_JOY_UP)		*y = -1000;
	if(st & JPF_JOY_DOWN)	*y =  1000;
	if(st & JPF_BUTTON_RED)		b |= AMIGA_JOYB_RED;
	if(st & JPF_BUTTON_BLUE)	b |= AMIGA_JOYB_BLUE;
	if(st & JPF_BUTTON_GREEN)	b |= AMIGA_JOYB_GREEN;
	if(st & JPF_BUTTON_YELLOW)	b |= AMIGA_JOYB_YELLOW;
	if(st & JPF_BUTTON_PLAY)	b |= AMIGA_JOYB_PLAY;
	if(st & JPF_BUTTON_FORWARD)	b |= AMIGA_JOYB_FORWARD;
	if(st & JPF_BUTTON_REVERSE)	b |= AMIGA_JOYB_REVERSE;
	return b;
}

/*************************************************************************************************
 * audio: ahi.device, or Paula directly through audio.device ([AMIGA] paula=1, or when AHI can't be
 * opened). The mixer fills one buffer at a time: amiga_audio_free() says how many frames it may write
 * now (0 while the next buffer is still playing), amiga_audio_write() queues them.
 *************************************************************************************************/
enum { SND_NONE, SND_AHI, SND_PAULA };
static int					g_sndmode = SND_NONE;
static int					g_sndfreq = 22050;	/* the rate the mixer runs at */
static unsigned int			g_sndsent = 0, g_snddone = 0, g_sndbusy = 0, g_snderrors = 0;
static unsigned int			g_sndunderruns = 0;	/* buffers queued after the device had run dry (a gap in the sound) */
static int					g_sndlasterr = 0;

/* Stall watchdog: if the device returns no buffer for SND_STALL_MS while some are queued (no audio mode
   set in AHI prefs, a driver waiting on a hidden requester, ...), the requests are aborted and the mixer
   is paced by the clock instead, silently. Without it the mixer never advances, and games that wait
   for a sound or tune to end freeze. */
#define SND_STALL_MS	2000
static unsigned int			g_sndbusysince = 0;	/* ms when the loop first found the next buffer still busy, 0 = not busy */
static int					g_sndstalled = 0;
static unsigned int			g_clockstart = 0, g_clockframes = 0;

/* Adaptive buffering: how much sound is queued decides both the latency of sound effects and whether
   a slow loop lets the device run dry (a gap). It starts short, grows by 30 ms on every gap and shrinks
   by 10 ms after 10 s without one, so fast machines settle low and slow ones get the buffer they need.
   The device buffers are allocated for the maximum; the mixer is told how much to write each time. */
#define SND_TARGET_START	120		/* ms queued over all buffers */
#define SND_TARGET_MIN		100
#define SND_TARGET_MAX		400
static int					g_sndtarget = SND_TARGET_START;
static unsigned int			g_sndtuned = 0;		/* ms of the last change of g_sndtarget */
static int					g_sndbuffers = 2;	/* buffers of the device in use */

static int SndMaxFrames( int buffers ) { return ((SND_TARGET_MAX*g_sndfreq/1000/buffers)+2) & ~1; }

static int SndChunk( void )
{
	int n = (g_sndtarget*g_sndfreq/1000/g_sndbuffers) & ~1;
	return n<256 ? 256 : n;
}

static void SndUnderrun( void )
{
	g_sndunderruns++;
	g_sndtarget += 30;
	if(g_sndtarget>SND_TARGET_MAX) g_sndtarget = SND_TARGET_MAX;
	g_sndtuned = amiga_ticks();
}

/*------------------------------------------------------------------------------------------------
 * AHI: two requests used alternately, each linked to the one playing: the double buffering AHI
 * documents. With four requests chained three deep, AHI returned the first two and never another.
 *------------------------------------------------------------------------------------------------*/
#define AHI_BUFFERS		2
static int					g_ahiframes = 0;	/* capacity of each buffer */

static struct MsgPort*		g_ahiport = NULL;
static struct AHIRequest*	g_ahireq[AHI_BUFFERS];
static short*				g_ahibuf[AHI_BUFFERS];
static int					g_ahipending[AHI_BUFFERS];
static int					g_ahinext = 0;		/* next slot to fill */
static int					g_ahilast = -1;		/* last slot sent (for ahir_Link) */
static int					g_ahiopen = 0;

static void AhiAbort( void )
{
	int i;
	for(i=0;i<AHI_BUFFERS;i++)
		if(g_ahireq[i] && g_ahipending[i])
		{
			AbortIO((struct IORequest*)g_ahireq[i]);
			WaitIO((struct IORequest*)g_ahireq[i]);
			g_ahipending[i] = 0;
		}
}

static void AhiClose( void )
{
	int i;
	AhiAbort();
	if(g_ahiopen && g_ahireq[0]) CloseDevice((struct IORequest*)g_ahireq[0]);
	g_ahiopen = 0;
	for(i=AHI_BUFFERS-1;i>=0;i--)
	{
		if(g_ahireq[i]) { if(i==0) DeleteIORequest((struct IORequest*)g_ahireq[0]); else FreeVec(g_ahireq[i]); g_ahireq[i]=NULL; }
		if(g_ahibuf[i]) { FreeVec(g_ahibuf[i]); g_ahibuf[i]=NULL; }
	}
	if(g_ahiport) { DeleteMsgPort(g_ahiport); g_ahiport=NULL; }
}

static int AhiOpen( void )
{
	int i;
	g_ahiframes = SndMaxFrames(AHI_BUFFERS);
	for(i=0;i<AHI_BUFFERS;i++) { g_ahireq[i]=NULL; g_ahibuf[i]=NULL; g_ahipending[i]=0; }
	g_ahiport = CreateMsgPort();
	if(!g_ahiport) return 0;
	g_ahireq[0] = (struct AHIRequest*)CreateIORequest(g_ahiport,sizeof(struct AHIRequest));
	if(!g_ahireq[0]) { AhiClose(); return 0; }
	g_ahireq[0]->ahir_Version = 4;
	if(OpenDevice((CONST_STRPTR)AHINAME,AHI_DEFAULT_UNIT,(struct IORequest*)g_ahireq[0],0)!=0)
	{
		DeleteIORequest((struct IORequest*)g_ahireq[0]); g_ahireq[0]=NULL;
		AhiClose();
		return 0;
	}
	g_ahiopen = 1;
	for(i=0;i<AHI_BUFFERS;i++)
	{
		if(i>0)
		{
			g_ahireq[i] = (struct AHIRequest*)AllocVec(sizeof(struct AHIRequest),MEMF_PUBLIC);
			if(!g_ahireq[i]) { AhiClose(); return 0; }
			CopyMem(g_ahireq[0],g_ahireq[i],sizeof(struct AHIRequest));
		}
		g_ahibuf[i] = (short*)AllocVec(g_ahiframes*4,MEMF_PUBLIC|MEMF_CLEAR);
		if(!g_ahibuf[i]) { AhiClose(); return 0; }
	}
	g_ahinext = 0;
	g_ahilast = -1;
	return 1;
}

/* frames writable now, 0 while the next buffer is still busy */
static int AhiFree( void )
{
	int i = g_ahinext;
	if(g_ahipending[i])
	{
		if(!CheckIO((struct IORequest*)g_ahireq[i])) return 0; /* still queued/playing */
		WaitIO((struct IORequest*)g_ahireq[i]);
		g_ahipending[i] = 0;
		g_snddone++;
		if(g_ahireq[i]->ahir_Std.io_Error) { g_snderrors++; g_sndlasterr = g_ahireq[i]->ahir_Std.io_Error; }
	}
	return g_ahiframes;
}

static void AhiWrite( const short* stereo, int frames )
{
	int i = g_ahinext;
	struct AHIRequest* r;
	if(frames>g_ahiframes) frames = g_ahiframes;
	CopyMem((APTR)stereo,g_ahibuf[i],frames*4);
	r = g_ahireq[i];
	r->ahir_Std.io_Message.mn_Node.ln_Pri = 0;
	r->ahir_Std.io_Command	= CMD_WRITE;
	r->ahir_Std.io_Data		= g_ahibuf[i];
	r->ahir_Std.io_Length	= frames*4;
	r->ahir_Std.io_Offset	= 0;
	r->ahir_Frequency		= g_sndfreq;
	r->ahir_Type			= AHIST_S16S;
	r->ahir_Volume			= 0x10000;
	r->ahir_Position		= 0x8000;
	/* link to the previous request only while AHI is still working on it, so they play back to back.
	   g_ahipending stays set until the request is reaped, and a request linked to one that AHI has
	   already finished never starts - the audio (and everything waiting for a sound to end) stalls. */
	r->ahir_Link			= (g_ahilast>=0 && g_ahipending[g_ahilast] && !CheckIO((struct IORequest*)g_ahireq[g_ahilast])) ? g_ahireq[g_ahilast] : NULL;
	if(!r->ahir_Link && g_sndsent>0) SndUnderrun();
	SendIO((struct IORequest*)r);
	g_sndsent++;
	g_ahipending[i] = 1;
	g_ahilast = i;
	g_ahinext = (i+1) % AHI_BUFFERS;
}

/*------------------------------------------------------------------------------------------------
 * Paula through audio.device: one left and one right channel, 8 bit samples in chip memory, three
 * buffers queued per channel. The sample rate is the Paula clock divided by a whole period, so the
 * mixer runs at that exact rate (22030 Hz for 22050 on PAL).
 *------------------------------------------------------------------------------------------------*/
#define PAULA_BUFFERS	3
static int					g_paulaframes = 0;	/* capacity of each buffer */
#define PAULA_CLOCK_PAL		3546895
#define PAULA_CLOCK_NTSC	3579545

static struct MsgPort*		g_paulaport = NULL;
static struct IOAudio*		g_paulaalloc = NULL;					/* holds the two channels */
static struct IOAudio*		g_paulareq[PAULA_BUFFERS][2];			/* [buffer][left/right] */
static BYTE*				g_paulabuf[PAULA_BUFFERS][2];			/* chip memory */
static int					g_paulapending[PAULA_BUFFERS];
static int					g_paulanext = 0;
static int					g_paulaopen = 0;
static int					g_paulastarted = 0;
static UWORD				g_paulaperiod = 161;

/* BeginIO() (amiga.lib, not linked): the device's BEGINIO vector, request in a1. Unlike SendIO() it
   keeps io_Flags, and audio.device needs ADIOF_PERVOL there to take the period and volume. */
static void DevBeginIO( struct IORequest* io )
{
	register struct IORequest* a1 __asm("a1") = io;
	register struct Device* a6 __asm("a6") = io->io_Device;
	__asm volatile ( "jsr -30(%%a6)" : "+r"(a1) : "r"(a6) : "d0", "d1", "a0", "memory", "cc" ); /* a0/a1/d0/d1 are scratch */
}

static void PaulaAbort( void )
{
	int i, s;
	for(i=0;i<PAULA_BUFFERS;i++)
		if(g_paulapending[i])
		{
			for(s=0;s<2;s++) { AbortIO((struct IORequest*)g_paulareq[i][s]); WaitIO((struct IORequest*)g_paulareq[i][s]); }
			g_paulapending[i] = 0;
		}
}

static void PaulaClose( void )
{
	int i, s;
	if(g_paulaopen) PaulaAbort();
	if(g_paulaopen) CloseDevice((struct IORequest*)g_paulaalloc); /* frees the channels */
	g_paulaopen = 0;
	for(i=0;i<PAULA_BUFFERS;i++)
		for(s=0;s<2;s++)
		{
			if(g_paulareq[i][s]) { FreeVec(g_paulareq[i][s]); g_paulareq[i][s]=NULL; }
			if(g_paulabuf[i][s]) { FreeVec(g_paulabuf[i][s]); g_paulabuf[i][s]=NULL; }
		}
	if(g_paulaalloc) { DeleteIORequest((struct IORequest*)g_paulaalloc); g_paulaalloc=NULL; }
	if(g_paulaport) { DeleteMsgPort(g_paulaport); g_paulaport=NULL; }
}

static int PaulaOpen( int* frequency )
{
	/* channel pairs with one left (0 or 3) and one right (1 or 2) channel, in order of preference */
	static UBYTE pairs[] = { 3, 5, 10, 12 };
	ULONG clock = (GfxBase->DisplayFlags & PAL) ? PAULA_CLOCK_PAL : PAULA_CLOCK_NTSC;
	ULONG period, mask;
	int i, s;
	for(i=0;i<PAULA_BUFFERS;i++) { g_paulapending[i]=0; for(s=0;s<2;s++) { g_paulareq[i][s]=NULL; g_paulabuf[i][s]=NULL; } }

	period = (clock + (ULONG)*frequency/2) / (ULONG)*frequency;
	if(period<124) period = 124;		/* Paula's limit without a productivity (31 kHz) display */
	if(period>65535) period = 65535;
	g_paulaperiod = (UWORD)period;
	*frequency = (int)(clock/period);
	g_sndfreq = *frequency;
	g_paulaframes = SndMaxFrames(PAULA_BUFFERS);

	g_paulaport = CreateMsgPort();
	if(!g_paulaport) return 0;
	g_paulaalloc = (struct IOAudio*)CreateIORequest(g_paulaport,sizeof(struct IOAudio));
	if(!g_paulaalloc) { PaulaClose(); return 0; }
	g_paulaalloc->ioa_Request.io_Message.mn_Node.ln_Pri = 90;	/* keep the channels (127 would lock others out) */
	g_paulaalloc->ioa_Data = pairs;
	g_paulaalloc->ioa_Length = sizeof(pairs);
	if(OpenDevice((CONST_STRPTR)AUDIONAME,0,(struct IORequest*)g_paulaalloc,0)!=0) { PaulaClose(); return 0; }
	g_paulaopen = 1;
	mask = (ULONG)g_paulaalloc->ioa_Request.io_Unit;

	for(i=0;i<PAULA_BUFFERS;i++)
		for(s=0;s<2;s++)
		{
			g_paulareq[i][s] = (struct IOAudio*)AllocVec(sizeof(struct IOAudio),MEMF_PUBLIC|MEMF_CLEAR);
			g_paulabuf[i][s] = (BYTE*)AllocVec(g_paulaframes,MEMF_CHIP|MEMF_CLEAR);
			if(!g_paulareq[i][s] || !g_paulabuf[i][s]) { PaulaClose(); return 0; }
			CopyMem(g_paulaalloc,g_paulareq[i][s],sizeof(struct IOAudio));		/* port, device, alloc key */
			g_paulareq[i][s]->ioa_Request.io_Unit = (struct Unit*)(s==0 ? (mask & 9) : (mask & 6));
		}

	/* hold both channels until the first buffers are queued on both, then start them together */
	g_paulaalloc->ioa_Request.io_Command = CMD_STOP;
	DoIO((struct IORequest*)g_paulaalloc);
	g_paulastarted = 0;
	g_paulanext = 0;
	return 1;
}

static int PaulaFree( void )
{
	int i = g_paulanext;
	if(g_paulapending[i])
	{
		if(!CheckIO((struct IORequest*)g_paulareq[i][0]) || !CheckIO((struct IORequest*)g_paulareq[i][1])) return 0;
		WaitIO((struct IORequest*)g_paulareq[i][0]);
		WaitIO((struct IORequest*)g_paulareq[i][1]);
		g_paulapending[i] = 0;
		g_snddone++;
		if(g_paulareq[i][0]->ioa_Request.io_Error) { g_snderrors++; g_sndlasterr = g_paulareq[i][0]->ioa_Request.io_Error; }
	}
	return g_paulaframes;
}

static void PaulaWrite( const short* stereo, int frames )
{
	int i = g_paulanext, s, k;
	BYTE* l = g_paulabuf[i][0];
	BYTE* r = g_paulabuf[i][1];
	if(frames>g_paulaframes-1) frames = g_paulaframes-1; /* room for the padding byte below */
	for(k=0;k<frames;k++) { l[k] = (BYTE)(stereo[k*2]>>8); r[k] = (BYTE)(stereo[k*2+1]>>8); }
	if(frames & 1) { l[frames] = 0; r[frames] = 0; frames++; } /* Paula plays words */
	if(frames<2) return;
	if(g_paulastarted) /* nothing left playing on the channels: the sound had a gap */
	{
		int j, busy = 0;
		for(j=0;j<PAULA_BUFFERS;j++) if(g_paulapending[j] && !CheckIO((struct IORequest*)g_paulareq[j][0])) busy = 1;
		if(!busy) SndUnderrun();
	}
	for(s=0;s<2;s++)
	{
		struct IOAudio* a = g_paulareq[i][s];
		a->ioa_Request.io_Command	= CMD_WRITE;
		a->ioa_Request.io_Flags		= ADIOF_PERVOL;
		a->ioa_Data					= (UBYTE*)g_paulabuf[i][s];
		a->ioa_Length				= frames;
		a->ioa_Period				= g_paulaperiod;
		a->ioa_Volume				= 64;
		a->ioa_Cycles				= 1;
		DevBeginIO((struct IORequest*)a);
	}
	g_sndsent++;
	g_paulapending[i] = 1;
	g_paulanext = (i+1) % PAULA_BUFFERS;
	if(!g_paulastarted)
	{
		g_paulaalloc->ioa_Request.io_Command = CMD_START;
		DoIO((struct IORequest*)g_paulaalloc);
		g_paulastarted = 1;
	}
}

/*------------------------------------------------------------------------------------------------
 * interface
 *------------------------------------------------------------------------------------------------*/
/* paula: 1 = Paula, 0 = AHI (Paula if AHI can't be opened). *frequency may change (Paula periods). */
int amiga_audio_open( int* frequency, int paula )
{
	g_sndmode = SND_NONE;
	g_sndstalled = 0;
	g_sndbusysince = 0;
	g_sndsent = g_snddone = g_sndbusy = g_snderrors = g_sndunderruns = 0;
	g_sndlasterr = 0;
	g_sndtarget = SND_TARGET_START;
	g_sndtuned = amiga_ticks();
	g_sndfreq = *frequency;
	if(!paula && AhiOpen()) { g_sndmode = SND_AHI; g_sndbuffers = AHI_BUFFERS; return 1; }
	if(PaulaOpen(frequency)) { g_sndmode = SND_PAULA; g_sndbuffers = PAULA_BUFFERS; g_sndfreq = *frequency; return 1; }
	return 0;
}

const char* amiga_audio_name( void )
{
	return g_sndmode==SND_AHI ? "ahi.device" : g_sndmode==SND_PAULA ? "Paula (audio.device)" : "none";
}

void amiga_audio_close( void )
{
	if(g_sndmode==SND_AHI) AhiClose();
	if(g_sndmode==SND_PAULA) PaulaClose();
	g_sndmode = SND_NONE;
}

int amiga_audio_free( void )
{
	int n;
	if(g_sndmode==SND_NONE) return 0;
	if(g_sndstalled)
	{
		unsigned int want = (unsigned int)(((unsigned long long)(amiga_ticks()-g_clockstart)*g_sndfreq)/1000);
		unsigned int left = want>g_clockframes ? want-g_clockframes : 0;
		return left>2048 ? 2048 : (int)left;
	}
	n = (g_sndmode==SND_AHI) ? AhiFree() : PaulaFree();
	if(n==0)
	{
		/* timed from the first busy check, not from the last completion: the game can block the
		   loop for seconds (loading) and must not mistake that for the device hanging */
		unsigned int now = amiga_ticks();
		g_sndbusy++;
		if(g_sndbusysince==0) g_sndbusysince = now ? now : 1;
		if(now-g_sndbusysince > SND_STALL_MS)
		{
			if(g_sndmode==SND_AHI) AhiAbort(); else PaulaAbort();
			g_sndstalled = 1;
			g_clockstart = amiga_ticks();
			g_clockframes = 0;
		}
		return 0;
	}
	g_sndbusysince = 0;
	{
		/* shrink the buffering again after a while without gaps */
		unsigned int now = amiga_ticks();
		if(now-g_sndtuned>10000 && g_sndtarget>SND_TARGET_MIN)
		{
			g_sndtarget -= 10;
			if(g_sndtarget<SND_TARGET_MIN) g_sndtarget = SND_TARGET_MIN;
			g_sndtuned = now;
		}
		if(n>SndChunk()) n = SndChunk();
	}
	return n;
}

void amiga_audio_write( const short* stereo, int frames )
{
	if(g_sndmode==SND_NONE) return;
	if(g_sndstalled) { g_clockframes += frames; return; }
	if(g_sndmode==SND_AHI) AhiWrite(stereo,frames); else PaulaWrite(stereo,frames);
}

int amiga_audio_stalled( void ) { return g_sndstalled; }

const char* amiga_audio_info( void )
{
	static char sz[128];
	sprintf(sz,"%s %s buffer=%ims sent=%u done=%u busy=%u underruns=%u errors=%u (last %i)%s",amiga_audio_name(),g_sndmode?"open":"closed",g_sndtarget,g_sndsent,g_snddone,g_sndbusy,g_sndunderruns,g_snderrors,g_sndlasterr,g_sndstalled?" STALLED":"");
	return sz;
}

/*************************************************************************************************
 * file system (dos.library)
 *************************************************************************************************/
int amiga_mkdir( const char* path )
{
	BPTR l = CreateDir((CONST_STRPTR)path);
	if(!l) return 0;
	UnLock(l);
	return 1;
}

int amiga_rmdir( const char* path )
{
	return DeleteFile((CONST_STRPTR)path) ? 1 : 0;
}

int amiga_getcwd( char* out, int size )
{
	if(!GetCurrentDirName((STRPTR)out,size)) { out[0]=0; return 0; }
	return (int)strlen(out);
}

int amiga_chdir( const char* path )
{
	BPTR l = Lock((CONST_STRPTR)path,ACCESS_READ);
	BPTR old;
	if(!l) return 0;
	old = CurrentDir(l);
	/* the lock we replaced is ours unless it is the original/program dir owned by the system */
	if(old && old!=g_oldcd && old!=GetProgramDir()) UnLock(old);
	return 1;
}

int amiga_scandir( const char* path, amiga_dircb cb, void* user )
{
	BPTR l;
	struct FileInfoBlock* fib;
	l = Lock((CONST_STRPTR)path,ACCESS_READ); /* "" locks the current dir */
	if(!l) return 0;
	fib = (struct FileInfoBlock*)AllocDosObject(DOS_FIB,NULL);
	if(!fib) { UnLock(l); return 0; }
	if(Examine(l,fib) && fib->fib_DirEntryType>0)
	{
		while(ExNext(l,fib))
		{
			char name[108];
			strncpy(name,(const char*)fib->fib_FileName,107); name[107]=0;
			cb(name, fib->fib_DirEntryType>0 ? 1 : 0, user);
		}
	}
	FreeDosObject(DOS_FIB,fib);
	UnLock(l);
	return 1;
}

int amiga_fileinfo( const char* path, long* size, long* mtime )
{
	BPTR l;
	struct FileInfoBlock* fib;
	int ok = 0;
	l = Lock((CONST_STRPTR)path,ACCESS_READ);
	if(!l) return 0;
	fib = (struct FileInfoBlock*)AllocDosObject(DOS_FIB,NULL);
	if(fib && Examine(l,fib) && fib->fib_DirEntryType<0)
	{
		if(size) *size = fib->fib_Size;
		/* AmigaDOS dates count from 1978-01-01, unix from 1970-01-01 (2922 days) */
		if(mtime) *mtime = (long)((fib->fib_Date.ds_Days+2922)*86400 + fib->fib_Date.ds_Minute*60 + fib->fib_Date.ds_Tick/TICKS_PER_SECOND);
		ok = 1;
	}
	if(fib) FreeDosObject(DOS_FIB,fib);
	UnLock(l);
	return ok;
}
