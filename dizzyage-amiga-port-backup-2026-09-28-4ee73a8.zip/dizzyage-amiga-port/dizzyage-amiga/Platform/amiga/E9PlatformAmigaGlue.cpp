///////////////////////////////////////////////////////////////////////////////////////////////////
// E9PlatformAmigaGlue.cpp  (AMIGA PORT)
// Engine side of the Amiga platform layer: implements the e9_* services, the input device class and
// the Win32-named file helpers on top of the plain C bridge (E9AmigaBridge.h / E9PlatformAmiga.c).
//
// [AMIGA] section in <game>.ini (all optional):
//   width=320 height=240 scale=1   back buffer size and game scale (see DizCfg.cpp)
//   modeid=0x....                  force a screen mode id (hex) instead of BestCModeID
//   depth=16                       screen depth to ask for (15/16/24/32)
//   double=0/1                     open a screen twice the size and pixel-double (auto if no small mode)
//   vsync=0/1                      WaitTOF() before each blit
//   audiofreq=22050                mixing frequency (with Paula, the nearest one its period allows)
//   paula=0                        1 = play through Paula (audio.device) instead of AHI; 0 = AHI, or
//                                  Paula when ahi.device can't be opened
//   joyport=1                      lowlevel.library port of the joystick (1 = normal joystick port)
//   directpresent=1                write frames straight into the locked screen bitmap (0 = WritePixelArray)
//   aga=-1                         1 = 256 color AGA screen, 0 = RTG only, -1 = RTG if possible, else AGA
//   akiko=1                        on AGA, use the Akiko chip's chunky to planar converter if it's there
//   profile=0                      1 = log a frame time breakdown to <game>.log every 5 seconds
///////////////////////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "E9System.h"
#include "D9Debug.h"
#include "I9Input.h"
#include "E9AmigaBridge.h"

BOOL e9_ini_get( const char* file, const char* group, const char* key, char* value, int size );

static char g_ininame[80] = "dizzy.ini";
static int ini_amiga( const char* key, int def )
{
	char sz[64];
	if(!e9_ini_get(g_ininame,"AMIGA",key,sz,64)) return def;
	return (int)strtoul(sz,NULL,0); // accepts 0x... for modeid
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// system
///////////////////////////////////////////////////////////////////////////////////////////////////
void e9_platform_args( int argc, char** argv )
{
	amiga_args(argc,argv);
	sprintf(g_ininame,"%s.ini",amiga_exename());
}
unsigned int	e9_platform_ticks()								{ return amiga_ticks(); }
unsigned int	e9_platform_uticks()							{ return amiga_uticks(); }
void			e9_platform_sleep( unsigned int ms )			{ amiga_sleep(ms); }
void			e9_platform_msgbox( const char* text, const char* caption ) { amiga_msgbox(text,caption); }
void			e9_platform_debugout( const char* msg )			{ amiga_debugout(msg); }
const char*		e9_platform_exename()							{ return amiga_exename(); }
BOOL			e9_platform_init()
{
	BOOL ok = amiga_init();
	dlog(LOGAPP,"AMIGA: timer %s\n",amiga_timer_info());
	e9_prof_on = ini_amiga("profile",0);
	return ok;
}
void			e9_platform_done()								{ amiga_done(); }

///////////////////////////////////////////////////////////////////////////////////////////////////
// video
///////////////////////////////////////////////////////////////////////////////////////////////////
BOOL e9_video_open( int width, int height )
{
	BOOL ok = amiga_video_open( width, height, ini_amiga("depth",16), ini_amiga("double",0), ini_amiga("vsync",0), (unsigned int)ini_amiga("modeid",0), ini_amiga("directpresent",1), ini_amiga("aga",-1), ini_amiga("akiko",1) );
	dlog( ok?LOGRND:LOGERR, "VIDEO: %s\n", amiga_video_info() );
	return ok;
}
void e9_video_close()												{ amiga_video_close(); }
void e9_video_present( const dword* argb, int width, int height )	{ amiga_video_present((const unsigned int*)argb,width,height); }

///////////////////////////////////////////////////////////////////////////////////////////////////
// events + input
///////////////////////////////////////////////////////////////////////////////////////////////////
#define KEYQ_SIZE 64
static int g_keyq[KEYQ_SIZE];
static int g_keyqn = 0;

BOOL e9_platform_events( BOOL* active )
{
	int act = *active ? 1 : 0;
	int keys[KEYQ_SIZE];
	int n = 0;
	if(!amiga_events(&act,keys,KEYQ_SIZE,&n)) return FALSE;
	for(int i=0;i<n && g_keyqn<KEYQ_SIZE;i++) g_keyq[g_keyqn++] = keys[i];
	if(e9_prof_on) // audio request counters next to the PROFILE lines
	{
		static unsigned int last = 0;
		unsigned int now = amiga_ticks();
		if(now-last>=5000) { last = now; dlog(LOGSND,"SOUND: %s\n",amiga_audio_info()); }
	}
	*active = act ? TRUE : FALSE;
	return TRUE;
}

class i9InputAmiga : public i9Input
{
public:
	BOOL		m_kbd, m_joy;
	int			m_joyport;
	unsigned	m_joyold;
	i9InputAmiga() { m_kbd=FALSE; m_joy=FALSE; m_joyport=1; m_joyold=0; }

	virtual BOOL DeviceInit( int device )
	{
		if(device==I9_DEVICE_KEYBOARD)	{ m_kbd=TRUE; return TRUE; }
		if(device==I9_DEVICE_JOYSTICK1 && amiga_joy_available())
		{
			m_joyport = ini_amiga("joyport",1);
			m_joy = TRUE; m_joyold = 0;
			return TRUE;
		}
		return FALSE;
	}
	virtual void DeviceDone( int device )		{ if(device==I9_DEVICE_KEYBOARD) m_kbd=FALSE; if(device==I9_DEVICE_JOYSTICK1) m_joy=FALSE; }
	virtual BOOL DeviceIsPresent( int device )	{ return (device==I9_DEVICE_KEYBOARD && m_kbd) || (device==I9_DEVICE_JOYSTICK1 && m_joy); }
	virtual void DeviceClear( int device )
	{
		if(device==I9_DEVICE_KEYBOARD) { for(int i=0;i<I9_KEYBOARD_KEYS;i++) m_key[i].m_value=0; g_keyqn=0; }
		if(device==I9_DEVICE_JOYSTICK1)
		{
			for(int i=0;i<I9_JOY_KEYS;i++) m_key[I9_JOY_FIRSTKEY(0)+i].m_value=0;
			m_axe[I9_JOY_X(0)].m_value=0; m_axe[I9_JOY_Y(0)].m_value=0;
			m_joyold=0;
		}
	}
	virtual void DeviceUpdate( int device )
	{
		if(device==I9_DEVICE_KEYBOARD)
		{
			for(int i=0;i<g_keyqn;i++) PushKey(g_keyq[i]&0xff,(g_keyq[i]&0x100)?1:0);
			g_keyqn = 0;
		}
		else if(device==I9_DEVICE_JOYSTICK1)
		{
			int x=0, y=0;
			unsigned b = amiga_joy_read(m_joyport,&x,&y);
			m_axe[I9_JOY_X(0)].m_delta = x - m_axe[I9_JOY_X(0)].m_value; m_axe[I9_JOY_X(0)].m_value = x;
			m_axe[I9_JOY_Y(0)].m_delta = y - m_axe[I9_JOY_Y(0)].m_value; m_axe[I9_JOY_Y(0)].m_value = y;
			// fire/red=B1 (joystick_b0: action), blue=B2 (joystick_b1: jump), green=B3 (joystick_b2: menu),
			// yellow=B4, play=B5, forward=B6, reverse=B7
			for(int k=0;k<7;k++)
			{
				BOOL now = (b>>k)&1, was = (m_joyold>>k)&1;
				if(now!=was) PushKey(I9_JOY_FIRSTKEY(0)+k,now);
			}
			m_joyold = b;
		}
	}
};
i9Input* I9_CreatePlatformInput() { return snew i9InputAmiga(); }

///////////////////////////////////////////////////////////////////////////////////////////////////
// audio
///////////////////////////////////////////////////////////////////////////////////////////////////
BOOL e9_audio_open( int* frequency )
{
	int freq = ini_amiga("audiofreq",*frequency);
	int paula = ini_amiga("paula",0);
	if(!amiga_audio_open(&freq,paula)) { dlog(LOGSND,"AUDIO: can't open %s\n",paula?"audio.device (Paula)":"ahi.device or audio.device (Paula)"); return FALSE; }
	dlog(LOGSND,"AUDIO: %s open, %i Hz%s\n",amiga_audio_name(),freq,(!paula && strcmp(amiga_audio_name(),"ahi.device")) ? " (ahi.device not available)" : "");
	*frequency = freq;
	return TRUE;
}
void e9_audio_close()										{ amiga_audio_close(); }
int  e9_audio_free()
{
	int n = amiga_audio_free();
	static BOOL warned = FALSE;
	if(!warned && amiga_audio_stalled())
	{
		warned = TRUE;
		dlog(LOGERR,"AUDIO: sound stopped playing (%s) - continuing without sound.%s\n",amiga_audio_info(),
			strcmp(amiga_audio_name(),"ahi.device")==0 ? " Check the audio mode of unit 0 in the AHI prefs, or try paula=1." : "");
	}
	return n;
}
void e9_audio_write( const short* stereo, int frames )		{ amiga_audio_write(stereo,frames); }

///////////////////////////////////////////////////////////////////////////////////////////////////
// file system
///////////////////////////////////////////////////////////////////////////////////////////////////
static char* amigapath( const char* path, char* buf )
{
	strcpy(buf,e9_hostpath(path?path:""));
	int n=(int)strlen(buf);
	if(n>0 && buf[n-1]=='/') buf[n-1]=0;
	return buf;
}
int   CreateDirectory( const char* path, void* )		{ char p[512]; return amiga_mkdir(amigapath(path,p)); }
int   RemoveDirectory( const char* path )				{ char p[512]; return amiga_rmdir(amigapath(path,p)); }
DWORD GetCurrentDirectory( DWORD size, char* out )		{ return (DWORD)amiga_getcwd(out,(int)size); }
int   SetCurrentDirectory( const char* path )			{ char p[512]; return amiga_chdir(amigapath(path,p)); }
int   e9_scandir( const char* dospath, e9_dircallback cb, void* user )	{ char p[512]; return amiga_scandir(amigapath(dospath,p),cb,user); }
int   e9_fileinfo( const char* dospath, long* size, long* mtime )		{ char p[512]; return amiga_fileinfo(amigapath(dospath,p),size,mtime); }

///////////////////////////////////////////////////////////////////////////////////////////////////
// No float math fallbacks here: libnix's libm (libm020/libm881, see Makefile.amiga) has sinf, cosf,
// powf, floorf and fabsf. Weak fallbacks written as (float)floor(x) were a trap: gcc folds that back
// into a call to floorf, so floorf called itself forever, and being defined in an object file they
// also kept the real libm versions from being linked.
///////////////////////////////////////////////////////////////////////////////////////////////////
