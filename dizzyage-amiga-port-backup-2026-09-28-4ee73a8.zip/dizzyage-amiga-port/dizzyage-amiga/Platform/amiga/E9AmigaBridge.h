/*************************************************************************************************
 * E9AmigaBridge.h  (AMIGA PORT)
 * Plain C interface between the engine side (E9PlatformAmigaGlue.cpp, which sees the Win32-style
 * engine types) and the AmigaOS side (E9PlatformAmiga.c, which sees exec/dos/intuition headers).
 * The two worlds can't share a translation unit: both define BOOL, WORD, BYTE, LONG, DeleteFile...
 * Only int/unsigned/char/short/void types cross this boundary.
 *************************************************************************************************/
#ifndef __E9AMIGABRIDGE_H__
#define __E9AMIGABRIDGE_H__

#ifdef __cplusplus
extern "C" {
#endif

/* startup / system */
void			amiga_args			( int argc, char** argv );		/* before anything else */
int				amiga_init			( void );						/* open libraries (after the log is up) */
void			amiga_done			( void );
unsigned int	amiga_ticks			( void );						/* milliseconds */
unsigned int	amiga_uticks		( void );						/* microseconds, wraps */
void			amiga_sleep			( unsigned int ms );
void			amiga_msgbox		( const char* text, const char* caption );
void			amiga_debugout		( const char* msg );
const char*		amiga_exename		( void );						/* "dizzy" */
const char*		amiga_timer_info	( void );						/* human readable timer state, for the log */

/* video: 32bit 0xAARRGGBB big-endian = RECTFMT_ARGB */
int				amiga_video_open	( int width, int height, int depth, int dbl, int vsync, unsigned int modeid, int directpresent, int aga, int akiko ); /* aga: 1 AGA, 0 RTG, -1 auto; akiko: use its c2p on AGA if present */
void			amiga_video_close	( void );
void			amiga_video_present	( const unsigned int* argb, int width, int height );
const char*		amiga_video_info	( void );						/* human readable mode description */

/* events: fills keys[] with (DirectInput scancode | 0x100 when pressed); returns 0 on quit request */
int				amiga_events		( int* active, int* keys, int maxkeys, int* nkeys );

/* joystick (lowlevel.library) */
int				amiga_joy_available	( void );
unsigned int	amiga_joy_read		( int port, int* x, int* y );	/* returns button bits, see AMIGA_JOYB_* */
#define AMIGA_JOYB_RED		(1<<0)
#define AMIGA_JOYB_BLUE		(1<<1)
#define AMIGA_JOYB_GREEN	(1<<2)
#define AMIGA_JOYB_YELLOW	(1<<3)
#define AMIGA_JOYB_PLAY		(1<<4)
#define AMIGA_JOYB_FORWARD	(1<<5)
#define AMIGA_JOYB_REVERSE	(1<<6)

/* audio (ahi.device or Paula through audio.device) - 16bit signed stereo, native order */
int				amiga_audio_open	( int* frequency, int paula );	/* paula: 1 Paula, 0 AHI (Paula if no AHI); may change *frequency */
const char*		amiga_audio_name	( void );						/* "ahi.device", "Paula (audio.device)" */
void			amiga_audio_close	( void );
int				amiga_audio_free	( void );						/* frames writable now */
void			amiga_audio_write	( const short* stereo, int frames );
const char*		amiga_audio_info	( void );						/* request counters, for the log */
int				amiga_audio_stalled	( void );						/* 1 = AHI stopped returning requests, running silent */

/* file system (paths already in AmigaDOS form) */
int				amiga_mkdir			( const char* path );
int				amiga_rmdir			( const char* path );
int				amiga_getcwd		( char* out, int size );
int				amiga_chdir			( const char* path );
typedef void (*amiga_dircb)( const char* name, int isdir, void* user );
int				amiga_scandir		( const char* path, amiga_dircb cb, void* user );
int				amiga_fileinfo		( const char* path, long* size, long* mtime );

#ifdef __cplusplus
}
#endif
#endif
