///////////////////////////////////////////////////////////////////////////////////////////////////
// E9PlatformCommon.cpp  (AMIGA PORT)
// Portable replacements for Win32 services: ini files, path conversion, _splitpath.
///////////////////////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "E9System.h"
#include "D9Debug.h"
#include <time.h>

///////////////////////////////////////////////////////////////////////////////////////////////////
// Frame profiler (see E9_PROF_BEGIN/END in E9System.h)
///////////////////////////////////////////////////////////////////////////////////////////////////
int e9_prof_on = 0;
static unsigned int g_prof_us[E9_PROF_SLOTS];
static unsigned int g_prof_frames = 0;
static unsigned int g_prof_start = 0;

void e9_prof_add( int slot, unsigned int us ) { g_prof_us[slot] += us; }

void e9_prof_frame()
{
	if(!e9_prof_on) return;
	unsigned int now = e9_platform_ticks();
	if(g_prof_start==0) { g_prof_start = now ? now : 1; memset(g_prof_us,0,sizeof(g_prof_us)); g_prof_frames = 0; return; }
	g_prof_frames++;
	unsigned int elapsed = now - g_prof_start;
	if(elapsed<5000) return;

	static const char* names[E9_PROF_SLOTS] = { "events", "update", "audio", "(decode)", "draw", "(clear)", "(room)", "(hud)", "present", "sleep",
												"| kpx fill", "copy", "key", "blend", "tint", "text", "generic" };
	char sz[256];
	unsigned int fps10 = g_prof_frames*10000/elapsed;
	int n = sprintf(sz,"PROFILE %u.%u fps, ms/frame:",fps10/10,fps10%10);
	for(int i=0;i<E9_PROF_SLOTS;i++)
	{
		unsigned int us = g_prof_us[i]/g_prof_frames;
		n += sprintf(sz+n," %s=%u.%u",names[i],us/1000,(us%1000)/100);
	}
	dlog(LOGAPP,"%s\n",sz);
	g_prof_start = now; memset(g_prof_us,0,sizeof(g_prof_us)); g_prof_frames = 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Paths
///////////////////////////////////////////////////////////////////////////////////////////////////
char* e9_hostpath( const char* path )
{
	static char out[512];
	if(!path) { out[0]=0; return out; }
	const char* s = path;
	char* d = out;
	char* end = out + sizeof(out) - 1;

	// strip leading ".\" or "./"
	while( s[0]=='.' && (s[1]=='\\' || s[1]=='/') ) s+=2;

	while(*s && d<end)
	{
#ifdef E9_PLATFORM_AMIGA
		// "..\" -> "/" (AmigaDOS parent), must be at a component start
		if( s[0]=='.' && s[1]=='.' && (s[2]=='\\' || s[2]=='/') && (s==path || s[-1]=='\\' || s[-1]=='/') )
		{
			*d++ = '/'; s+=3; continue;
		}
#endif
		char c = *s++;
		if(c=='\\') c='/';
#ifdef E9_PLATFORM_POSIX
		c = (char)tolower((unsigned char)c); // host test only: games assume a case-insensitive file system
#endif
		*d++ = c;
	}
	*d = 0;
	return out;
}

void _splitpath( const char* path, char* drive, char* dir, char* fname, char* ext )
{
	if(drive) drive[0]=0;
	if(dir) dir[0]=0;
	if(fname) fname[0]=0;
	if(ext) ext[0]=0;
	if(!path) return;

	const char* lastsep = NULL;
	for(const char* c=path; *c; c++) if(*c=='\\' || *c=='/' || *c==':') lastsep=c;
	const char* name = lastsep ? lastsep+1 : path;
	const char* dot = strrchr(name,'.');

	if(dir && lastsep) { int n=(int)(lastsep-path+1); memcpy(dir,path,n); dir[n]=0; }
	if(dot)
	{
		if(fname) { int n=(int)(dot-name); memcpy(fname,name,n); fname[n]=0; }
		if(ext) strcpy(ext,dot);
	}
	else
	{
		if(fname) strcpy(fname,name);
	}
}

BOOL e9_ini_get( const char* file, const char* group, const char* key, char* value, int size );
void e9_ini_set( const char* file, const char* group, const char* key, const char* value );

///////////////////////////////////////////////////////////////////////////////////////////////////
// Ini files (GetPrivateProfileString / WritePrivateProfileString replacement)
// Simple, tolerant parser: [group] lines, key=value lines, ';' comments. Case-insensitive names.
// The whole file is rewritten on every set; the game only writes a handful of keys at init.
///////////////////////////////////////////////////////////////////////////////////////////////////
static char* ini_load( const char* file, long* outsize )
{
	FILE* f = fopen( e9_hostpath(file), "rb" );
	if(!f) { *outsize=0; return NULL; }
	fseek(f,0,SEEK_END);
	long size = ftell(f);
	fseek(f,0,SEEK_SET);
	char* buf = (char*)malloc(size+1);
	if(!buf) { fclose(f); *outsize=0; return NULL; }
	size = (long)fread(buf,1,size,f);
	buf[size]=0;
	fclose(f);
	*outsize = size;
	return buf;
}

static void ini_trim( char* s )
{
	char* p = s;
	while(*p==' ' || *p=='\t') p++;
	if(p!=s) memmove(s,p,strlen(p)+1);
	int n = (int)strlen(s);
	while(n>0 && (s[n-1]==' ' || s[n-1]=='\t' || s[n-1]=='\r' || s[n-1]=='\n')) s[--n]=0;
}

// finds the key; returns TRUE and copies the value. Also reports byte ranges used by set:
// keystart/keyend = line range of the key (if found), groupend = offset where to insert in the group (-1 if no group)
static BOOL ini_find( const char* buf, long size, const char* group, const char* key, char* value, int valuesize, long* keystart, long* keyend, long* groupend )
{
	*keystart = *keyend = -1; *groupend = -1;
	BOOL ingroup = FALSE;
	long pos = 0;
	char line[512];
	while(pos<size)
	{
		long linestart = pos;
		long e = pos;
		while(e<size && buf[e]!='\n') e++;
		long lineend = (e<size) ? e+1 : e;
		int n = (int)(e-pos); if(n>511) n=511;
		memcpy(line,buf+pos,n); line[n]=0;
		ini_trim(line);
		pos = lineend;

		if(line[0]=='[')
		{
			char* c = strchr(line,']');
			if(c) *c=0;
			if(ingroup) return FALSE; // left our group without finding the key
			ingroup = (e9_stricmp(line+1,group)==0);
			if(ingroup) *groupend = lineend;
			continue;
		}
		if(!ingroup) continue;
		if(line[0]==0 || line[0]==';') continue;
		*groupend = lineend;
		char* eq = strchr(line,'=');
		if(!eq) continue;
		*eq = 0;
		ini_trim(line);
		if(e9_stricmp(line,key)!=0) continue;
		char* v = eq+1;
		ini_trim(v);
		if(value && valuesize>0) { strncpy(value,v,valuesize-1); value[valuesize-1]=0; }
		*keystart = linestart; *keyend = lineend;
		return TRUE;
	}
	return FALSE;
}

BOOL e9_ini_get( const char* file, const char* group, const char* key, char* value, int size )
{
	if(!file || !group || !key) return FALSE;
	long bufsize;
	char* buf = ini_load(file,&bufsize);
	if(!buf) { if(value && size>0) value[0]=0; return FALSE; }
	long ks,ke,ge;
	BOOL ok = ini_find(buf,bufsize,group,key,value,size,&ks,&ke,&ge);
	free(buf);
	if(!ok && value && size>0) value[0]=0;
	return ok;
}

void e9_ini_set( const char* file, const char* group, const char* key, const char* value )
{
	if(!file || !group || !key || !value) return;
	long bufsize;
	char* buf = ini_load(file,&bufsize);
	long ks=-1,ke=-1,ge=-1;
	char old[256];
	if(buf && ini_find(buf,bufsize,group,key,old,256,&ks,&ke,&ge))
		if(strcmp(old,value)==0) { free(buf); return; } // unchanged, avoid disk writes

	FILE* f = fopen( e9_hostpath(file), "wb" );
	if(!f) { if(buf) free(buf); return; }
	char line[512];
	snprintf(line,sizeof(line),"%s=%s\n",key,value);
	if(buf && ks>=0) // replace existing line
	{
		fwrite(buf,1,ks,f);
		fputs(line,f);
		fwrite(buf+ke,1,bufsize-ke,f);
	}
	else if(buf && ge>=0) // insert at the end of the group
	{
		fwrite(buf,1,ge,f);
		if(ge>0 && buf[ge-1]!='\n') fputs("\n",f);
		fputs(line,f);
		fwrite(buf+ge,1,bufsize-ge,f);
	}
	else // new group at the end
	{
		if(buf && bufsize>0) { fwrite(buf,1,bufsize,f); if(buf[bufsize-1]!='\n') fputs("\n",f); }
		fprintf(f,"[%s]\n",group);
		fputs(line,f);
	}
	fclose(f);
	if(buf) free(buf);
}

///////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////
// Win32 emulation
///////////////////////////////////////////////////////////////////////////////////////////////////
void GetLocalTime( SYSTEMTIME* st )
{
	time_t t = time(NULL);
	struct tm* lt = localtime(&t);
	memset(st,0,sizeof(SYSTEMTIME));
	if(!lt) return;
	st->wYear = (WORD)(lt->tm_year+1900); st->wMonth = (WORD)(lt->tm_mon+1); st->wDayOfWeek = (WORD)lt->tm_wday;
	st->wDay = (WORD)lt->tm_mday; st->wHour = (WORD)lt->tm_hour; st->wMinute = (WORD)lt->tm_min; st->wSecond = (WORD)lt->tm_sec;
}

DWORD GetTickCount() { return e9_platform_ticks(); }

DWORD GetFullPathName( const char* file, DWORD size, char* out, char** filepart )
{
	if(!file || !out || size==0) return 0;
	strncpy(out,file,size-1); out[size-1]=0; // relative paths stay relative (resolved against PROGDIR:)
	if(filepart) *filepart = NULL;
	return (DWORD)strlen(out);
}

DWORD GetPrivateProfileString( const char* group, const char* key, const char* def, char* out, DWORD size, const char* file )
{
	if(!e9_ini_get(file,group,key,out,(int)size)) { strncpy(out,def?def:"",size-1); out[size-1]=0; }
	return (DWORD)strlen(out);
}

int WritePrivateProfileString( const char* group, const char* key, const char* value, const char* file )
{
	e9_ini_set(file,group,key,value?value:"");
	return 1;
}

int DeleteFile( const char* path )				{ return remove(e9_hostpath(path))==0; }
// CreateDirectory, RemoveDirectory, Get/SetCurrentDirectory, e9_scandir, e9_fileinfo: per platform

DWORD GetModuleFileName( void* module, char* out, DWORD size )
{
	snprintf(out,size,"%s.exe",e9_platform_exename());
	return (DWORD)strlen(out);
}

int _memicmp( const void* a, const void* b, size_t n )
{
	const unsigned char* x=(const unsigned char*)a; const unsigned char* y=(const unsigned char*)b;
	for(size_t i=0;i<n;i++) { int c=tolower(x[i])-tolower(y[i]); if(c) return c; }
	return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// E9System.h pieces
///////////////////////////////////////////////////////////////////////////////////////////////////
struct e9FindCtx { const char* path; file_ffcallback cb; dword flags; };
static void e9_findfiles_cb( const char* name, int isdir, void* user )
{
	e9FindCtx* c = (e9FindCtx*)user;
	char fpath[512];
	snprintf(fpath,sizeof(fpath),"%s%s",c->path?c->path:"",name);
	_strlwr(fpath);
	if(isdir)
	{
		if(c->flags & FILE_FINDDIR) c->cb(fpath,1);
		strcat(fpath,"\\");
		if(c->flags & FILE_FINDREC) file_findfiles(fpath,c->cb,c->flags);
	}
	else c->cb(fpath,0);
}

void file_findfiles( char* path, file_ffcallback ffcallback, dword flags )
{
	e9FindCtx c = { path, ffcallback, flags };
	e9_scandir(path,e9_findfiles_cb,&c);
}

int sys_desktopwidth()	{ return 640; }
int sys_desktopheight()	{ return 480; }

///////////////////////////////////////////////////////////////////////////////////////////////////
// Global new/delete on malloc/free: the engine allocates objects with d9Memory::New (malloc) and
// releases them with plain delete, which MSVC's CRT tolerated. Make it well defined everywhere.
///////////////////////////////////////////////////////////////////////////////////////////////////
#include <new>
void* operator new( size_t size )				{ void* p=malloc(size?size:1); if(!p) { e9_platform_msgbox("Out of memory","DizzyAGE"); exit(20); } return p; }
void* operator new[]( size_t size )				{ void* p=malloc(size?size:1); if(!p) { e9_platform_msgbox("Out of memory","DizzyAGE"); exit(20); } return p; }
void  operator delete( void* p ) throw()		{ free(p); }
void  operator delete[]( void* p ) throw()		{ free(p); }
void  operator delete( void* p, size_t ) throw()	{ free(p); }
void  operator delete[]( void* p, size_t ) throw()	{ free(p); }
