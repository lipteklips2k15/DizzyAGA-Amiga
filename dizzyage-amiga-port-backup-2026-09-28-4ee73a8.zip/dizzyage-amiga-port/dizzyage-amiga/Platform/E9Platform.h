///////////////////////////////////////////////////////////////////////////////////////////////////
// E9Platform.h  (AMIGA PORT)
// Replaces <windows.h> for non-Windows builds. Provides just enough of the Win32 names used by the
// DizzyAGE engine so that the portable parts compile unchanged.
//
// Build defines:
//   E9_PLATFORM_AMIGA  - AmigaOS 3.x (m68k-amigaos-gcc / bebbo amiga-gcc)
//   E9_PLATFORM_POSIX  - host test build (Linux/macOS/MSYS), headless, used to shake out bugs
///////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef __E9PLATFORM_H__
#define __E9PLATFORM_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>
#include <math.h>
#include <stddef.h>
#include <stdint.h>

#if !defined(E9_PLATFORM_AMIGA) && !defined(E9_PLATFORM_POSIX)
#error "Define E9_PLATFORM_AMIGA or E9_PLATFORM_POSIX"
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////
// Endianness
///////////////////////////////////////////////////////////////////////////////////////////////////
#if defined(E9_PLATFORM_AMIGA) || defined(__BIG_ENDIAN__) || (defined(__BYTE_ORDER__) && __BYTE_ORDER__==__ORDER_BIG_ENDIAN__)
#define E9_BIG_ENDIAN 1
#endif

// Read/write little-endian values from byte memory. Always byte-wise: safe on any alignment and any
// host endianness. Data files (map, pak, wav, tga, zip) were all written on little-endian PCs.
static inline unsigned int   e9_rdle32( const void* p ) { const unsigned char* b=(const unsigned char*)p; return (unsigned int)b[0] | ((unsigned int)b[1]<<8) | ((unsigned int)b[2]<<16) | ((unsigned int)b[3]<<24); }
static inline unsigned short e9_rdle16( const void* p ) { const unsigned char* b=(const unsigned char*)p; return (unsigned short)(b[0] | (b[1]<<8)); }
static inline void           e9_wrle32( void* p, unsigned int v ) { unsigned char* b=(unsigned char*)p; b[0]=(unsigned char)v; b[1]=(unsigned char)(v>>8); b[2]=(unsigned char)(v>>16); b[3]=(unsigned char)(v>>24); }
static inline void           e9_wrle16( void* p, unsigned short v ) { unsigned char* b=(unsigned char*)p; b[0]=(unsigned char)v; b[1]=(unsigned char)(v>>8); }

// Convert a value that was loaded raw from a little-endian file into host order (in place helpers).
static inline unsigned int   e9_swap32( unsigned int v )   { return (v>>24) | ((v>>8)&0xff00) | ((v<<8)&0xff0000) | (v<<24); }
static inline unsigned short e9_swap16( unsigned short v ) { return (unsigned short)((v>>8)|(v<<8)); }
#ifdef E9_BIG_ENDIAN
#define E9_LE32(v)	e9_swap32((unsigned int)(v))
#define E9_LE16(v)	e9_swap16((unsigned short)(v))
#else
#define E9_LE32(v)	((unsigned int)(v))
#define E9_LE16(v)	((unsigned short)(v))
#endif
// fix an array of 32bit words just read from a little-endian file
static inline void e9_fixle32array( void* data, int count ) {
#ifdef E9_BIG_ENDIAN
	unsigned int* p=(unsigned int*)data; for(int i=0;i<count;i++) p[i]=e9_swap32(p[i]);
#else
	(void)data; (void)count;
#endif
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Win32 types
///////////////////////////////////////////////////////////////////////////////////////////////////
typedef void*			HWND;
typedef void*			HINSTANCE;
typedef void*			HMODULE;
typedef void*			HANDLE;
typedef void*			HICON;
typedef void*			HCURSOR;
typedef void*			HDC;
typedef long long		__int64;
typedef size_t			SIZE_T;
typedef intptr_t		INT_PTR;
typedef uintptr_t		UINT_PTR;
typedef intptr_t		LONG_PTR;
typedef uintptr_t		ULONG_PTR;
typedef unsigned int	UINT;
typedef long			LONG;
typedef unsigned long	DWORD;
typedef unsigned short	WORD;
typedef unsigned char	BYTE;
typedef char*			LPSTR;
typedef const char*		LPCSTR;
typedef intptr_t		LRESULT;
typedef uintptr_t		WPARAM;
typedef intptr_t		LPARAM;
typedef long			HRESULT;

#define CALLBACK
#define __fastcall
#define APIENTRY
#define WINAPI
#define __cdecl
#define __stdcall
#define __forceinline		inline
#define _inline				inline
#define __inline			inline

#ifndef MAX_PATH
#define MAX_PATH			256
#endif
#define _MAX_PATH			256
#define _MAX_DRIVE			8
#define _MAX_DIR			256
#define _MAX_FNAME			256
#define _MAX_EXT			256
#define INFINITE			0xFFFFFFFF

// Win32 values (scripts may register/compare them)
#define MB_OK				0x00
#define MB_OKCANCEL			0x01
#define MB_ABORTRETRYIGNORE	0x02
#define MB_YESNOCANCEL		0x03
#define MB_YESNO			0x04
#define MB_RETRYCANCEL		0x05
#define MB_ICONERROR		0x10
#define MB_ICONQUESTION		0x20
#define MB_ICONEXCLAMATION	0x30
#define MB_ICONWARNING		0x30
#define MB_ICONINFORMATION	0x40
#define MB_SYSTEMMODAL		0x1000
#define IDOK				1
#define IDCANCEL			2
#define IDABORT				3
#define IDRETRY				4
#define IDIGNORE			5
#define IDYES				6
#define IDNO				7

typedef struct tagPOINT { LONG x, y; } POINT;
typedef struct tagRECT { LONG left, top, right, bottom; } RECT;

#define MAKEINTRESOURCE(i)	((char*)(intptr_t)(i))
#define FAILED(hr)			(((HRESULT)(hr)) < 0)
#define SUCCEEDED(hr)		(((HRESULT)(hr)) >= 0)
#define ZeroMemory(p,s)		memset((p),0,(s))

///////////////////////////////////////////////////////////////////////////////////////////////////
// MSVC CRT names
///////////////////////////////////////////////////////////////////////////////////////////////////
#define stricmp				e9_stricmp
#define strnicmp			e9_strnicmp
#define _stricmp			e9_stricmp
#define _strnicmp			e9_strnicmp
#define _vsnprintf			vsnprintf
#define _snprintf			snprintf
#define _strdup				strdup
#define _itoa(v,s,r)		e9_itoa((v),(s),(r))
#define itoa(v,s,r)			e9_itoa((v),(s),(r))
#ifndef alloca
#define alloca				__builtin_alloca
#endif
#define _alloca				alloca
#define _isnan				isnan
#define _finite				isfinite

// own case-insensitive compares (libnix naming varies)
static inline int e9_strnicmp( const char* a, const char* b, size_t n )
{
	for(size_t i=0;i<n;i++) { int ca=tolower((unsigned char)a[i]), cb=tolower((unsigned char)b[i]); if(ca!=cb) return ca-cb; if(!ca) return 0; }
	return 0;
}
static inline int e9_stricmp( const char* a, const char* b ) { return e9_strnicmp(a,b,(size_t)-1); }

static inline char* _strlwr( char* s ) { for(char* p=s; p && *p; p++) *p=(char)tolower((unsigned char)*p); return s; }
static inline char* _strupr( char* s ) { for(char* p=s; p && *p; p++) *p=(char)toupper((unsigned char)*p); return s; }
#define strlwr	_strlwr
#define strupr	_strupr
static inline char* e9_itoa( int v, char* s, int radix ) { if(radix==16) sprintf(s,"%x",v); else sprintf(s,"%d",v); return s; }

// path helper: _splitpath (drive part is always empty on non-DOS systems; Amiga volume stays in dir)
void _splitpath( const char* path, char* drive, char* dir, char* fname, char* ext );

// Convert a DOS style relative path ("Data\\map\\x.map", ".\\x", "..\\x") into a host path.
// Returns a pointer to a static buffer. Implemented in E9PlatformCommon.cpp
char* e9_hostpath( const char* path );

///////////////////////////////////////////////////////////////////////////////////////////////////
// Small Win32 API emulation used by the script libraries (E9PlatformCommon.cpp)
///////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct _SYSTEMTIME { WORD wYear, wMonth, wDayOfWeek, wDay, wHour, wMinute, wSecond, wMilliseconds; } SYSTEMTIME;
void	GetLocalTime( SYSTEMTIME* st );
DWORD	GetTickCount();
DWORD	GetFullPathName( const char* file, DWORD size, char* out, char** filepart );
DWORD	GetPrivateProfileString( const char* group, const char* key, const char* def, char* out, DWORD size, const char* file );
int		WritePrivateProfileString( const char* group, const char* key, const char* value, const char* file );
int		DeleteFile( const char* path );
int		CreateDirectory( const char* path, void* security );
int		RemoveDirectory( const char* path );
DWORD	GetCurrentDirectory( DWORD size, char* out );
int		SetCurrentDirectory( const char* path );
DWORD	GetModuleFileName( void* module, char* out, DWORD size );	// returns "<exename>.exe" so the game derives <exename>.ini/.pak/.log
int		_memicmp( const void* a, const void* b, size_t n );

// directory scan: callback gets the entry name (no path) and dir flag; returns FALSE if path can't be read
typedef void (*e9_dircallback)( const char* name, int isdir, void* user );
int		e9_scandir( const char* dospath, e9_dircallback cb, void* user );
// file info: size and modification time (seconds since 1970); FALSE if missing or a directory
int		e9_fileinfo( const char* dospath, long* size, long* mtime );

// Platform services implemented per-platform (E9PlatformAmiga.cpp / E9PlatformPosix.cpp)
unsigned int	e9_platform_ticks();					// milliseconds, monotonic
unsigned int	e9_platform_uticks();					// microseconds, wraps around (profiling only)
void			e9_platform_sleep( unsigned int ms );
void			e9_platform_msgbox( const char* text, const char* caption );
void			e9_platform_debugout( const char* msg );
const char*		e9_platform_exename();				// program name without path, e.g. "dizzy"

#endif
///////////////////////////////////////////////////////////////////////////////////////////////////
